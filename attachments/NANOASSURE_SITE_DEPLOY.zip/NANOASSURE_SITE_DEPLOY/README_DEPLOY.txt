SP NanoAssure™ — Website & Platform Deploy Package
===================================================
Date: 2026-08-23

CONTENTS
--------
index.html                                      Public website (entry)
SP_NanoAssure_Public_Careers.html               Careers
SP_NanoAssure_Employment_Workforce_Portal.html  Employment / workforce portal
SP_NanoAssure_Command_Centre_Hub.html           Staff command hub
media/
  nanoassure-hero.jpg                           Hero visual (water repulsion)
  before-glass.jpg / after-glass.jpg            Comparison slider
  sp-logo.png / sp-logo-sm.png                  Logo assets
brand/
  sp-logo-canonical.png                         Master logo

HOW TO VIEW LOCALLY
-------------------
1. Unzip this folder
2. Open index.html in a browser FROM THIS FOLDER
   (so media/ paths resolve)

NETLIFY DROP (fastest)
----------------------
1. Go to https://app.netlify.com/drop
2. Drag this whole folder onto the page
3. Copy the live URL Netlify gives you

NETLIFY PROJECT (domain: nanoassure.net)
----------------------------------------
1. New site from folder / drag-drop / CLI
2. Publish directory = this folder root (where index.html sits)
3. No build command needed (static HTML)
4. Point DNS: nanoassure.net → Netlify as instructed in Netlify domain settings

BRAND RULES (locked)
--------------------
• ANALYSIS pathway only — no public prices / quotes
• analysis@nanoassure.net for analysis
• No public phone numbers on site
• Canonical SP gold + cyan droplet shield only
• Videos removed from public site

CONTACT
-------
Analysis: analysis@nanoassure.net
General:  samsprowashsolutions@gmail.com
