# Sam's Prowash Solutions — Compliance & Supabase Migration Notes
**Internal Director brief · August 2026**

---

## 1. Completed this session

### Audit Trail (complete)
- Shared `spAudit()` engine in `auth.js`
- Events now logged:
  - SUBSTRATE_TEST_LOGGED / SUBSTRATE_TEST_APPROVED
  - ENVIRONMENTAL_CHECK_LOGGED / ENVIRONMENTAL_CHECK_APPROVED
  - NANOASSURE_DIGITAL_VERIFICATION (with Verification ID)
  - TIME_CLOCK
  - EXPENSE_LOGGED
  - CERTIFICATE_OF_COMPETENCY_VIEWED
  - CULTURAL_SCREENING / CULTURAL_ENGAGEMENT
  - CULTURAL_INCIDENT_LOGGED / CULTURAL_INCIDENT_RESOLVED
- Director Command Centre → **Audit Trail** tab (view + JSON export)
- Recent audit entries included in Director branded report

### Verify-by-ID (complete)
- Public page: `verify.html`
- Lookup by Nanoassure Digital Verification ID (`NA-YYYYMMDD-XXXX`)
- Linked from Portal Gallery and from the certificate “Public Verify Link” button
- Currently device-local (localStorage); will become multi-device once Supabase is live

### Reports
- Verification ID present in: Daily Report, Director Report, Cultural Report, Client Portal, QA Register, Certificate

---

## 2. GDPR & Australian Privacy — Practical Rules for SP

### Does GDPR apply to us?
We are an Australian company (ABN 95 698 841 128) operating primarily in the NT/Australia.

**GDPR applies only if we:**
- Offer goods/services to individuals **in the EU/EEA/UK**, or
- Monitor the behaviour of individuals in the EU/EEA/UK, or
- Have an establishment in the EU.

For pure Australian commercial / government / body-corporate work, **Australian Privacy Act 1988 (APPs)** is the primary regime. GDPR becomes relevant if we later market to EU clients or process EU personal data.

**Recommended stance:** Design the platform to meet the stricter of APP + GDPR principles so we are future-proof.

### Personal data we currently handle
| Data type | Examples in platform | Sensitivity |
|-----------|----------------------|-------------|
| Staff | Names, employee numbers, timesheets, leave, TFN declaration status, incident notes | Medium–High |
| Client / site | Job names, addresses, access notes, GPS coordinates | Medium |
| Photos | Substrate / environmental test photos (may show identifiable locations or people) | Medium–High |
| Financial | Receipts, amounts, vendors, payroll figures | Medium |
| Cultural | Community contacts, screening notes, incident details | Higher (can include sensitive context) |
| Auth | PINs, role, session timestamps | Low–Medium |

### Core obligations (APP + GDPR-aligned)

1. **Lawful basis / purpose**  
   Collect only what is needed for Nanoassure QA, warranty, payroll, WHS and cultural governance. Document the purpose.

2. **Transparency**  
   Publish a clear Privacy Policy (website + client portal). Tell staff and clients what is collected, why, and how long it is kept.

3. **Minimisation**  
   Photos should be compressed (we already do). Avoid storing unnecessary free-text that identifies third parties.

4. **Security**  
   - Current client-side localStorage is **not** adequate for production personal data.  
   - Move to Supabase with RLS, encrypted at rest, HTTPS only, MFA for Director accounts.

5. **Access & correction**  
   Staff and clients must be able to request access/correction. Build a simple export of “my data” once Supabase is live.

6. **Retention**  
   Define periods (e.g. job evidence 7 years for warranty/tax; timesheets 7 years; audit trail 7 years; photos after warranty expiry may be reduced).

7. **Cross-border (APP 8)**  
   Supabase can host in a chosen region. Prefer **ap-southeast-2 (Sydney)** so data stays in Australia and APP 8 risk is minimised. If any EU data is later processed, use SCCs / DPA with the provider.

8. **Breach notification**  
   Under the Notifiable Data Breaches scheme (Australia) and GDPR (if applicable), have a simple internal incident process: detect → contain → assess → notify OAIC / individuals if required.

9. **Small business note**  
   Current small-business exemption under the Privacy Act is expected to be removed or narrowed in 2026–2027 reforms. Treat full APP compliance as inevitable.

### Immediate platform actions for privacy
- [x] Audit trail of who accessed/changed critical QA records
- [ ] Add privacy notice link on Client Portal and Gallery
- [ ] Prefer Australian Supabase region
- [ ] Role-based access (already partially modelled) → enforce with RLS
- [ ] Ability to export / delete a staff member’s personal records on request

---

## 3. Supabase Migration Plan

### Why Supabase
- Postgres + Auth + Storage + Realtime in one product
- Row Level Security matches our Director / Cultural / Operations / Staff roles
- Storage for field photos (currently lost on refresh)
- Free tier sufficient for early production
- Works with existing Netlify static hosting

### Target architecture

```
Browser (gallery, portals)
    ↓ supabase-js (anon key)
Supabase project (ap-southeast-2)
    ├── Auth (email or magic link; roles in app_metadata)
    ├── Postgres tables + RLS
    ├── Storage bucket: field-photos
    └── Realtime (optional for Live Tracker / Intercom)
```

### Core tables (first cut)

| Table | Purpose | Replaces |
|-------|---------|----------|
| `profiles` | user id, role, display name | auth.js roles |
| `projects` | 22-step jobs | sp_ops.projs |
| `substrate_tests` | Nanoassure substrate tests | sp_ops.tests |
| `environmental_checks` | Nanoassure env checks | sp_ops.envs |
| `qa_signoffs` | Nanoassure Digital Verification | sp_nanoassure_verifications + qaLog |
| `staff` / `timesheets` / `incidents` | HR & clock | sp_ops staff/clocks |
| `chemical_mixes` | mixing log | sp_ops chemicals |
| `cultural_engagements` | community log | sp_cultural.engs |
| `cultural_screenings` | risk screening | sp_cultural.screens |
| `cultural_incidents` | concerns + SLA | sp_cultural.incs |
| `receipts` | expenses | spw_receipts_v1 |
| `certifications` | academy register | sp_cert_register |
| `audit_events` | Nanoassure Audit Trail | sp_audit_trail |
| `client_access` | QR codes / job status | client portal |

### RLS sketch (role-based)

```sql
-- Example: only operations + director can insert substrate tests
CREATE POLICY "ops_insert_tests" ON substrate_tests
  FOR INSERT TO authenticated
  WITH CHECK ( (auth.jwt() ->> 'role') IN ('operations','director') );

-- Director can read everything
CREATE POLICY "director_read_all" ON substrate_tests
  FOR SELECT TO authenticated
  USING ( (auth.jwt() ->> 'role') = 'director' );
```

Roles stored in `auth.users.raw_app_meta_data.role` or a `profiles.role` column.

### Migration phases (recommended)

**Phase 0 – Project setup (1 day)**  
Create Supabase project in **Sydney (ap-southeast-2)**. Enable Auth, create Storage bucket `field-photos` (private).

**Phase 1 – Parallel write (3–5 days)**  
Add `supabase.js` client. On every existing `save()` / `spAudit()` / certificate action, also write to Supabase. Keep localStorage as fallback. No user-facing change yet.

**Phase 2 – Auth replacement (2–3 days)**  
Replace client-side password/PIN with Supabase Auth (email magic link or password). Map roles: director / cultural / operations / staff. Keep visual overlays.

**Phase 3 – Read path switch (2–3 days)**  
Pages load from Supabase first, fall back to localStorage. Photo upload goes to Storage; URLs stored in test rows.

**Phase 4 – Cut-over & harden (2 days)**  
Remove localStorage writes for production data. Enable RLS on all tables. Turn on SSL enforcement + MFA for Director. Add privacy policy link and data-export endpoint.

**Phase 5 – Realtime & client verify (optional)**  
Live Tracker and Intercom via Realtime broadcast. Public `verify.html` queries `qa_signoffs` by Verification ID (read-only policy).

### Security checklist before production
- [ ] RLS enabled on every table
- [ ] No service-role key in the browser
- [ ] Sydney region confirmed
- [ ] Storage policies: only authenticated roles can upload; signed URLs for read
- [ ] MFA for Director account
- [ ] Audit events table append-only (no update/delete for normal roles)
- [ ] Privacy policy published
- [ ] Retention job (Edge Function or scheduled) for old photos / drafts

### Estimated effort
- Schema + RLS + client library: 1–2 days  
- Parallel write for Ops + Cultural + Receipts + Audit: 3–4 days  
- Auth switch: 2–3 days  
- Photo storage + full cut-over: 3–4 days  
- Testing & staff training: ongoing  

**Total realistic window: ~2–3 weeks of focused work** to production-grade multi-device platform.

---

## 4. Recommended next concrete step

1. Create the Supabase project (Sydney).  
2. Run the SQL schema for the first four tables: `profiles`, `qa_signoffs`, `substrate_tests`, `audit_events`.  
3. Add a single `supabaseClient.js` and wire **Nanoassure Digital Verification** + **Audit Trail** as the first parallel-write proof of concept.

Once that path is proven, roll the same pattern across the rest of the modules.

## 5. RLS Implementation Status (Aug 2026)

- Full schema + RLS policies: `supabase/schema.sql`
- Client scaffold + parallel writes: `supabaseClient.js`
- Public verify uses SECURITY DEFINER function `verify_nanoassure(text)`
- Roles: director, cultural, operations, staff, client
- Audit events are append-only for non-director roles
- QA sign-offs parallel-write from Kate Operations when keys are configured
- Storage policies for `field-photos` bucket included (commented until bucket created)

**To activate:** Create Supabase project (Sydney) → run schema.sql → set URL + anon key in supabaseClient.js → create Director user and set role.
