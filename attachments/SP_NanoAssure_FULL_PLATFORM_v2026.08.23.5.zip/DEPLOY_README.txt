SP NanoAssure™ FULL PLATFORM — DEPLOYMENT NOTE
=============================================
This ZIP is structured as a complete static deployment package. index.html is at the ZIP root.

For the existing Netlify site:
1. Deploy the entire contents of this package together.
2. Do not deploy only employment.html; shared assets, auth.js, employment-data.js, calc-widget.js and portal pages are required.
3. After deployment, check the public website and select Staff Portal.
4. Clean Staff Portal URL: https://www.nanoassure.net/staff
5. Confirm gallery.html loads, then open Employment & Workforce and verify the tool links.

Important: auth.js is client-side gating only; it is not production server security.
