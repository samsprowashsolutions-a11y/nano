/* ============================================================
   Sam's Prowash Solutions (SP) — Access Control
   ------------------------------------------------------------
   IMPORTANT — READ THIS:
   This is a CLIENT-SIDE gate only. It keeps casual visitors out
   of internal pages and stops someone browsing straight to a
   portal URL without going through the front door first. It is
   NOT cryptographic security — anyone who views this file's
   source (or the page source) can read the password/PIN values
   below. Do NOT rely on this alone to protect real client
   financial data or anything genuinely sensitive. If that's
   needed, this should be upgraded to real server-side auth
   (e.g. Netlify Identity) rather than a static password check.

   HOW IT WORKS:
   - gallery.html is the front door: one password, checked once,
     valid for 24 hours (stored in this browser only).
   - Every internal portal page checks that the front-door gate
     was passed, then asks for a short PIN. Roles are shared as follows:
       • Director (Sam) PIN unlocks Director Command + Financials
       • Cultural (Jas) and Operations (Kate) PINs are interchangeable
         for field platforms: Operations Command, Cultural Command,
         Training Academy, Receipt Scanner, Daily Report, Chemical Lab
       • Financials (Tax & Financial Control) and personal/sensitive
         document areas remain Director-only (+ financials section PIN)
   - Once a role PIN is entered, that role stays unlocked for the rest
     of THIS browser tab session.
   - client.html is deliberately NOT gated — it's the public/QR
     client-facing page and must stay open with no login.
   - Receipt logging is available to Sam, Jas and Kate.
   - Employee onboarding & training (Academy) is available to Jas
     (primary) and also Kate/Sam via interchangeable access.

   TO CHANGE THE PASSWORD/PINS: edit the values below, then
   re-deploy this one file — every page picks up the change
   automatically since they all load this same file.
   ============================================================ */

const SP_AUTH = {
  MAIN_PASSWORD: 'SPAdvanced2026',   // CHANGE ME — front-door password for gallery.html
  PINS: {
    director:    '1955',   // CHANGE ME — Sam
    cultural:    '2966',   // CHANGE ME — Jaz
    operations:  '3977'    // CHANGE ME — Kate
  },
  SECTION_PINS: {
    financials: '7410'     // CHANGE ME — extra lock on Tax & Financial Control Center
  },
  GATE_VALID_HOURS: 24
};

function spCheckMainGate(){
  const stored = localStorage.getItem('sp_gate_ok');
  if(!stored) return false;
  const hours = (Date.now() - parseInt(stored,10)) / 3600000;
  return hours >= 0 && hours < SP_AUTH.GATE_VALID_HOURS;
}

function spShowBody(){
  document.body.style.visibility = 'visible';
}

/* For shared utility pages that need the front-door password but no specific role PIN (e.g. QR generator) */
function spRequireMainGateOnly(){
  if(!spCheckMainGate()){
    window.location.href = 'gallery.html';
    return;
  }
  spShowBody();
}

function spOverlayShell(innerHTML){
  const overlay = document.createElement('div');
  overlay.id = 'spAuthOverlay';
  overlay.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(5,5,8,.97);display:flex;align-items:center;justify-content:center;font-family:"Segoe UI",sans-serif;padding:1rem;';
  overlay.innerHTML = `<div style="max-width:340px;width:100%;border-radius:18px;padding:2px;background:conic-gradient(from 180deg,#1FA8A0,#3EE0D6,#F0D68C,#1FA8A0)">
    <div style="border-radius:16px;padding:2rem 1.6rem;background:linear-gradient(155deg,#2a1a42,#1c1230);text-align:center;position:relative;overflow:hidden">
      ${innerHTML}
    </div></div>`;
  document.body.appendChild(overlay);
  return overlay;
}

/* ---- Front door (gallery.html only) ---- */
function spShowMainGate(){
  if(spCheckMainGate()){ spShowBody(); return; }
  document.body.style.visibility = 'hidden';
  const overlay = spOverlayShell(`
    <div style="font-size:.72rem;letter-spacing:.12em;text-transform:uppercase;color:#9AA0A8;margin-bottom:.5rem">Sam's Prowash Solutions (SP)</div>
    <div style="font-size:1.1rem;font-weight:700;color:#F0D68C;margin-bottom:1.3rem">Staff Portal Access</div>
    <input id="spMainPw" type="password" placeholder="Password" style="width:100%;padding:.75rem;border-radius:8px;text-align:center;font-size:1rem;background:#150a24;border:1px solid rgba(103,232,224,.4);color:#f2eafc;outline:none;box-sizing:border-box">
    <div id="spMainErr" style="color:#f0a0a0;font-size:.76rem;margin-top:.6rem;min-height:1.1em"></div>
    <button id="spMainBtn" style="margin-top:1rem;width:100%;padding:.75rem;border-radius:8px;font-weight:800;border:none;cursor:pointer;background:linear-gradient(135deg,#F0D68C,#C9A227);color:#1a1206">Enter</button>
  `);
  const input = overlay.querySelector('#spMainPw');
  const tryUnlock = () => {
    if(input.value === SP_AUTH.MAIN_PASSWORD){
      localStorage.setItem('sp_gate_ok', Date.now().toString());
      overlay.remove();
      document.body.style.visibility = 'visible';
    } else {
      overlay.querySelector('#spMainErr').textContent = 'Incorrect password.';
      input.value=''; input.focus();
    }
  };
  overlay.querySelector('#spMainBtn').onclick = tryUnlock;
  input.addEventListener('keydown', e => { if(e.key==='Enter') tryUnlock(); });
  setTimeout(()=>input.focus(), 50);
}

/* ---- Portal pages: pass an array of allowed roles, e.g. spProtectPage(['director']) or spProtectPage(['director','cultural']) for shared tools ---- */
function spProtectPage(roles){
  if(!spCheckMainGate()){
    window.location.href = 'gallery.html';
    return;
  }
  const alreadyUnlocked = roles.some(r => sessionStorage.getItem('sp_pin_'+r) === 'ok');
  if(alreadyUnlocked){ spShowBody(); return; }

  document.body.style.visibility = 'hidden';
  const label = roles.length > 1 ? 'Staff PIN' : roles[0].charAt(0).toUpperCase()+roles[0].slice(1)+' PIN';
  const overlay = spOverlayShell(`
    <div style="font-size:.72rem;letter-spacing:.12em;text-transform:uppercase;color:#9AA0A8;margin-bottom:.5rem">Sam's Prowash Solutions (SP)</div>
    <div style="font-size:1.05rem;font-weight:700;color:#F0D68C;margin-bottom:1.2rem">Enter ${label}</div>
    <input id="spPinInput" type="password" inputmode="numeric" maxlength="8" style="width:100%;padding:.7rem;border-radius:8px;text-align:center;font-size:1.3rem;letter-spacing:.3em;background:#150a24;border:1px solid rgba(103,232,224,.4);color:#f2eafc;outline:none;box-sizing:border-box">
    <div id="spPinError" style="color:#f0a0a0;font-size:.78rem;margin-top:.6rem;min-height:1.2em"></div>
    <button id="spPinSubmit" style="margin-top:1rem;width:100%;padding:.7rem;border-radius:8px;font-weight:800;border:none;cursor:pointer;background:linear-gradient(135deg,#F0D68C,#C9A227);color:#1a1206">Unlock</button>
    <a href="gallery.html" style="display:block;margin-top:1rem;font-size:.75rem;color:#3EE0D6;text-decoration:none">← Back to Portal Gallery</a>
  `);
  const input = overlay.querySelector('#spPinInput');
  const tryUnlock = () => {
    const match = roles.find(r => input.value === SP_AUTH.PINS[r]);
    if(match){
      sessionStorage.setItem('sp_pin_'+match, 'ok');
      sessionStorage.setItem('sp_role', match);
      // Field staff interchangeability: Cultural (Jas) and Operations (Kate)
      // unlock each other's platforms for this session. Director stays separate.
      if(match === 'cultural' || match === 'operations'){
        sessionStorage.setItem('sp_pin_cultural', 'ok');
        sessionStorage.setItem('sp_pin_operations', 'ok');
      }
      // Director also receives field access (Sam can use all platforms)
      if(match === 'director'){
        sessionStorage.setItem('sp_pin_cultural', 'ok');
        sessionStorage.setItem('sp_pin_operations', 'ok');
        sessionStorage.setItem('sp_pin_director', 'ok');
      }
      overlay.remove();
      document.body.style.visibility = 'visible';
    } else {
      overlay.querySelector('#spPinError').textContent = 'Incorrect PIN.';
      input.value=''; input.focus();
    }
  };
  overlay.querySelector('#spPinSubmit').onclick = tryUnlock;
  input.addEventListener('keydown', e => { if(e.key==='Enter') tryUnlock(); });
  setTimeout(()=>input.focus(), 50);
}

/* ---- Sub-section PIN (e.g. Financials tab inside an already-unlocked portal) ----
   Usage: spProtectSection('financials') at the top of the section's own script,
   with the section's content wrapped in <div id="sp-section-financials" style="display:none">...</div>
   Reveals the div only after the section PIN is entered. Stays unlocked for this tab session. */
function spProtectSection(sectionKey){
  const container = document.getElementById('sp-section-' + sectionKey);
  if(!container) return;
  if(sessionStorage.getItem('sp_section_'+sectionKey) === 'ok'){
    container.style.display = '';
    return;
  }
  const overlay = spOverlayShell(`
    <div style="font-size:.72rem;letter-spacing:.12em;text-transform:uppercase;color:#9AA0A8;margin-bottom:.5rem">Restricted Section</div>
    <div style="font-size:1.05rem;font-weight:700;color:#F0D68C;margin-bottom:1.2rem">${sectionKey.charAt(0).toUpperCase()+sectionKey.slice(1)} — Enter PIN</div>
    <input id="spSecPin" type="password" inputmode="numeric" maxlength="8" style="width:100%;padding:.7rem;border-radius:8px;text-align:center;font-size:1.3rem;letter-spacing:.3em;background:#150a24;border:1px solid rgba(103,232,224,.4);color:#f2eafc;outline:none;box-sizing:border-box">
    <div id="spSecErr" style="color:#f0a0a0;font-size:.78rem;margin-top:.6rem;min-height:1.2em"></div>
    <button id="spSecBtn" style="margin-top:1rem;width:100%;padding:.7rem;border-radius:8px;font-weight:800;border:none;cursor:pointer;background:linear-gradient(135deg,#F0D68C,#C9A227);color:#1a1206">Unlock Section</button>
  `);
  const input = overlay.querySelector('#spSecPin');
  const tryUnlock = () => {
    if(input.value === SP_AUTH.SECTION_PINS[sectionKey]){
      sessionStorage.setItem('sp_section_'+sectionKey, 'ok');
      overlay.remove();
      container.style.display = '';
    } else {
      overlay.querySelector('#spSecErr').textContent = 'Incorrect PIN.';
      input.value=''; input.focus();
    }
  };
  overlay.querySelector('#spSecBtn').onclick = tryUnlock;
  input.addEventListener('keydown', e => { if(e.key==='Enter') tryUnlock(); });
  setTimeout(()=>input.focus(), 50);
}

/* ============================================================
   Nanoassure™ Audit Trail
   Shared activity log for Quality Assurance & Digital Verification.
   Every critical action writes a structured entry that can be
   reviewed by the Director (and exported).
   ============================================================ */
const SP_AUDIT_KEY = 'sp_audit_trail';
const SP_AUDIT_MAX = 500;

function spAudit(action, details, module){
  try {
    const entry = {
      id: 'AUD-' + Date.now() + '-' + Math.floor(Math.random()*900+100),
      ts: new Date().toLocaleString('en-AU', {timeZone:'Australia/Darwin'}),
      tsIso: new Date().toISOString(),
      action: String(action || 'UNKNOWN'),
      details: details || {},
      module: module || 'platform',
      role: sessionStorage.getItem('sp_role') || localStorage.getItem('sp_last_role') || 'unknown'
    };
    let log = [];
    try { log = JSON.parse(localStorage.getItem(SP_AUDIT_KEY) || '[]'); } catch(e){}
    log.unshift(entry);
    if(log.length > SP_AUDIT_MAX) log = log.slice(0, SP_AUDIT_MAX);
    localStorage.setItem(SP_AUDIT_KEY, JSON.stringify(log));
    return entry.id;
  } catch(e){
    console.warn('spAudit failed', e);
    return null;
  }
}

function spGetAuditTrail(limit){
  try {
    const log = JSON.parse(localStorage.getItem(SP_AUDIT_KEY) || '[]');
    return limit ? log.slice(0, limit) : log;
  } catch(e){ return []; }
}

function spClearAuditTrail(){
  try { localStorage.removeItem(SP_AUDIT_KEY); } catch(e){}
}
