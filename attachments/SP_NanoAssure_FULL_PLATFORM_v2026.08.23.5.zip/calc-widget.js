/* Sam's Prowash Solutions — floating Pay / GST / Super calculator widget */
(function () {
  if (window.__spCalcWidgetLoaded) return;
  window.__spCalcWidgetLoaded = true;

  const HIST_KEY = 'sp_pay_calc_history';

  const css = `
  #spCalcFab{
    position:fixed;right:18px;bottom:18px;z-index:99990;
    width:56px;height:56px;border-radius:50%;border:none;cursor:pointer;
    background:linear-gradient(135deg,#F0D68C,#C9A227);color:#1a1206;
    font-weight:900;font-size:1.25rem;box-shadow:0 8px 28px rgba(0,0,0,.45),0 0 0 1px rgba(232,236,240,.25);
  }
  #spCalcFab:hover{transform:scale(1.05);}
  #spCalcWidget{
    display:none;position:fixed;z-index:99991;width:min(340px,calc(100vw - 24px));
    right:18px;bottom:84px;background:linear-gradient(165deg,#2a1a42,#1c1230);
    border:1px solid rgba(217,180,74,.45);border-radius:16px;padding:14px 14px 12px;
    box-shadow:0 16px 48px rgba(0,0,0,.55),0 0 0 1px rgba(232,236,240,.12);
    color:#e8e0f0;font-family:system-ui,sans-serif;backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);
  }
  #spCalcWidget.open{display:block;}
  #spCalcWidget .hd{display:flex;justify-content:space-between;align-items:center;cursor:move;margin-bottom:8px;}
  #spCalcWidget .hd b{color:#F0D68C;font-size:.95rem;}
  #spCalcWidget .hd button{background:transparent;border:none;color:#9AA0A8;font-size:1.1rem;cursor:pointer;padding:4px 8px;}
  #spCalcWidget label{display:block;font-size:.65rem;letter-spacing:.06em;text-transform:uppercase;color:#9AA0A8;margin:6px 0 3px;}
  #spCalcWidget input,#spCalcWidget select{
    width:100%;padding:8px 10px;border-radius:8px;border:1px solid rgba(103,232,224,.3);
    background:#150a24;color:#f2eafc;font-size:.9rem;box-sizing:border-box;
  }
  #spCalcWidget .row{display:grid;grid-template-columns:1fr 1fr;gap:8px;}
  #spCalcWidget .go{
    width:100%;margin-top:10px;padding:10px;border:none;border-radius:10px;font-weight:800;cursor:pointer;
    background:linear-gradient(135deg,#F0D68C,#C9A227);color:#1a1206;
  }
  #spCalcWidget .out{margin-top:8px;font-size:.82rem;line-height:1.4;color:#3EE0D6;font-weight:700;min-height:2.4em;}
  #spCalcWidget .links{margin-top:8px;display:flex;gap:8px;flex-wrap:wrap;}
  #spCalcWidget .links a{font-size:.72rem;color:#3EE0D6;text-decoration:none;}
  #spCalcWidget .note{font-size:.65rem;color:#9AA0A8;margin-top:6px;line-height:1.35;}
  `;

  const style = document.createElement('style');
  style.textContent = css;
  document.head.appendChild(style);

  const fab = document.createElement('button');
  fab.id = 'spCalcFab';
  fab.type = 'button';
  fab.title = 'Pay / GST / Super calculator';
  fab.setAttribute('aria-label', 'Open calculator widget');
  fab.textContent = '₿';
  // Use $ if bitcoin symbol odd on some devices
  fab.textContent = '$';

  const panel = document.createElement('div');
  panel.id = 'spCalcWidget';
  panel.innerHTML = `
    <div class="hd" id="spCalcDrag">
      <b>$ Calculator</b>
      <div>
        <button type="button" id="spCalcExpand" title="Full page">⛶</button>
        <button type="button" id="spCalcClose" title="Close">✕</button>
      </div>
    </div>
    <label>Type</label>
    <select id="spWType">
      <option value="staff">Staff (PAYG + Super)</option>
      <option value="subcontractor">Subcontractor (GST)</option>
    </select>
    <div class="row">
      <div><label>Gross $</label><input id="spWGross" type="number" step="0.01" value="1000"/></div>
      <div><label>Hours</label><input id="spWHours" type="number" step="0.25" value="38"/></div>
    </div>
    <div id="spWStaff">
      <div class="row">
        <div><label>Super %</label><input id="spWSuper" type="number" step="0.1" value="11.5"/></div>
        <div><label>PAYG %</label><input id="spWPayg" type="number" step="0.1" value="20"/></div>
      </div>
    </div>
    <div id="spWSub" style="display:none;">
      <label>GST registered?</label>
      <select id="spWGst"><option value="yes">Yes +10% GST</option><option value="no">No GST</option></select>
    </div>
    <button type="button" class="go" id="spWGo">Calculate</button>
    <div class="out" id="spWOut">Free-use widget · results stay on this device</div>
    <div class="links">
      <a href="pay-calculator.html">Open full calculator + graphs</a>
    </div>
    <p class="note">Estimates only — not tax advice. Drag header to move.</p>
  `;

  function mount() {
    if (!document.body) return;
    document.body.appendChild(fab);
    document.body.appendChild(panel);
  }
  if (document.body) mount();
  else document.addEventListener('DOMContentLoaded', mount);

  function toggle(open) {
    if (open === undefined) panel.classList.toggle('open');
    else panel.classList.toggle('open', !!open);
  }

  fab.addEventListener('click', () => toggle());
  document.addEventListener('click', (e) => {
    // close handled by button
  });

  panel.addEventListener('click', (e) => e.stopPropagation());

  function bind() {
    const close = document.getElementById('spCalcClose');
    const expand = document.getElementById('spCalcExpand');
    const type = document.getElementById('spWType');
    const go = document.getElementById('spWGo');
    if (!close) return;

    close.onclick = () => toggle(false);
    expand.onclick = () => { location.href = 'pay-calculator.html'; };
    type.onchange = () => {
      const sub = type.value === 'subcontractor';
      document.getElementById('spWStaff').style.display = sub ? 'none' : 'block';
      document.getElementById('spWSub').style.display = sub ? 'block' : 'none';
    };
    go.onclick = () => {
      const t = type.value;
      const gross = parseFloat(document.getElementById('spWGross').value) || 0;
      const hours = parseFloat(document.getElementById('spWHours').value) || 0;
      let text = '', net = 0, note = '';
      if (t === 'staff') {
        const superR = (parseFloat(document.getElementById('spWSuper').value) || 0) / 100;
        const paygR = (parseFloat(document.getElementById('spWPayg').value) || 0) / 100;
        const superAmt = gross * superR;
        const payg = gross * paygR;
        net = gross - payg;
        text = 'Net est. $' + net.toFixed(2) + ' · PAYG −$' + payg.toFixed(2) + ' · Super $' + superAmt.toFixed(2);
        note = 'Super $' + superAmt.toFixed(2);
      } else {
        const gstOn = document.getElementById('spWGst').value === 'yes';
        const gst = gstOn ? gross * 0.1 : 0;
        net = gross + gst;
        text = 'Invoice $' + gross.toFixed(2) + (gstOn ? ' + GST $' + gst.toFixed(2) + ' = $' + net.toFixed(2) : ' (no GST)');
        note = gstOn ? 'GST $' + gst.toFixed(2) : 'No GST';
      }
      if (hours > 0) text += ' · $' + (gross / hours).toFixed(2) + '/hr';
      document.getElementById('spWOut').textContent = text;
      try {
        const h = JSON.parse(localStorage.getItem(HIST_KEY) || '[]');
        h.unshift({ at: new Date().toLocaleString('en-AU', { timeZone: 'Australia/Darwin' }), type: t, gross, net, note, text });
        localStorage.setItem(HIST_KEY, JSON.stringify(h.slice(0, 60)));
      } catch (e) {}
    };

    // Drag
    const handle = document.getElementById('spCalcDrag');
    let ox = 0, oy = 0, dragging = false;
    handle.addEventListener('mousedown', (e) => {
      if (e.target.tagName === 'BUTTON') return;
      dragging = true;
      const r = panel.getBoundingClientRect();
      ox = e.clientX - r.left; oy = e.clientY - r.top;
      panel.style.right = 'auto'; panel.style.bottom = 'auto';
      panel.style.left = r.left + 'px'; panel.style.top = r.top + 'px';
      e.preventDefault();
    });
    window.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      panel.style.left = Math.max(8, e.clientX - ox) + 'px';
      panel.style.top = Math.max(8, e.clientY - oy) + 'px';
    });
    window.addEventListener('mouseup', () => { dragging = false; });
    // touch
    handle.addEventListener('touchstart', (e) => {
      if (e.target.tagName === 'BUTTON') return;
      const t = e.touches[0];
      const r = panel.getBoundingClientRect();
      dragging = true;
      ox = t.clientX - r.left; oy = t.clientY - r.top;
      panel.style.right = 'auto'; panel.style.bottom = 'auto';
      panel.style.left = r.left + 'px'; panel.style.top = r.top + 'px';
    }, { passive: true });
    window.addEventListener('touchmove', (e) => {
      if (!dragging) return;
      const t = e.touches[0];
      panel.style.left = Math.max(8, t.clientX - ox) + 'px';
      panel.style.top = Math.max(8, t.clientY - oy) + 'px';
    }, { passive: true });
    window.addEventListener('touchend', () => { dragging = false; });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bind);
  else setTimeout(bind, 0);

  window.spOpenCalcWidget = () => toggle(true);
  window.spCloseCalcWidget = () => toggle(false);
})();
