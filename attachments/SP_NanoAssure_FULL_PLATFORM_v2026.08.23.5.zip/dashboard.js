/**
 * SAM'S PRO-WASH COMMAND CENTRE
 * Complete business management dashboard
 * All data stored in localStorage (client-side)
 */

// ============================================================
// DATA STORE
// ============================================================
const DB = {
  get(key) { try { return JSON.parse(localStorage.getItem('spw_' + key) || 'null'); } catch(e) { return null; } },
  set(key, val) { localStorage.setItem('spw_' + key, JSON.stringify(val)); },
  init() {
    if (!this.get('initialized')) {
      this.set('initialized', true);
      this.set('jobs', []);
      this.set('clients', []);
      this.set('team', []);
      this.set('equipment', []);
      this.set('checklists', []);
      this.set('settings', {
        reportEmail: 'samsprowashsolutions@gmail.com',
        reportEmailCC: 'j.calma@live.com.au',
        reportTime: '18:00',
        autoSend: true,
        bizName: "Sam's Pro-Wash Solutions",
        bizPhone: '0455 581 715',
        bizABN: '',
        bizAddress: 'Darwin, NT'
      });
      this.seedDemoData();
    }
  },
  seedDemoData() {
    const today = new Date().toISOString().split('T')[0];
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
    const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];

    // Demo clients
    this.set('clients', [
      { id: 'c1', firstName: 'John', lastName: 'Smith', phone: '0412 345 678', email: 'john@example.com', address: '45 Sunset Dr, Coconut Grove NT', type: 'residential', notes: 'Repeat customer, prefers morning appointments' },
      { id: 'c2', firstName: 'Sarah', lastName: 'Johnson', phone: '0423 456 789', email: 'sarah@smithco.com.au', address: '12 Cavenagh St, Darwin CBD NT', type: 'commercial', notes: 'Smith & Co - quarterly contract' },
      { id: 'c3', firstName: 'Darwin', lastName: 'High School', phone: '0889 123 456', email: 'facilities@darwinhigh.edu.au', address: '93 Bullocky Point Rd, Darwin NT', type: 'school', notes: 'School holidays only' },
      { id: 'c4', firstName: 'Mike', lastName: 'Chen', phone: '0434 567 890', email: 'mike@palmerstonplaza.com', address: '18 Temple Tce, Palmerston NT', type: 'commercial', notes: 'Shopping centre - after hours' },
      { id: 'c5', firstName: 'Emma', lastName: 'Williams', phone: '0411 222 333', email: 'emma.w@live.com.au', address: '8 Casuarina Dr, Nightcliff NT', type: 'residential', notes: 'Referred by John Smith' }
    ]);

    // Demo team
    this.set('team', [
      { id: 't1', firstName: 'Sam', lastName: 'ProWash', phone: '0455 581 715', email: 'samsprowashsolutions@gmail.com', role: 'Owner', notes: 'Business owner' },
      { id: 't2', firstName: 'Jaz', lastName: 'Calma', phone: '0400 000 000', email: 'j.calma@live.com.au', role: 'Co-Owner', notes: 'Marketing & partnerships' },
      { id: 't3', firstName: 'Alex', lastName: 'Johnson', phone: '0422 333 444', email: 'alex@spw.com', role: 'Supervisor', notes: 'Field supervisor' },
      { id: 't4', firstName: 'Jordan', lastName: 'Smith', phone: '0433 444 555', email: 'jordan@spw.com', role: 'Operator', notes: 'Pressure washing specialist' }
    ]);

    // Demo equipment
    this.set('equipment', [
      { id: 'e1', name: 'Honda GX390 Pressure Washer', type: 'pressure-washer', status: 'available', model: 'PX4000', purchaseDate: '2024-01-15', notes: '4000 PSI, main unit' },
      { id: 'e2', name: 'Surface Cleaner 20"', type: 'surface-cleaner', status: 'in-use', model: 'SC-20', purchaseDate: '2024-02-01', notes: 'Whirlaway style' },
      { id: 'e3', name: 'Work Ute #1', type: 'vehicle', status: 'available', model: 'Toyota Hilux 2023', purchaseDate: '2023-06-01', notes: 'Main work vehicle' },
      { id: 'e4', name: 'Nano Ceramic Treatment Kit', type: 'chemical', status: 'available', model: 'NanoShield Pro', purchaseDate: '2024-03-10', notes: 'Premium treatment solution' },
      { id: 'e5', name: 'Hot Water Unit', type: 'pressure-washer', status: 'maintenance', model: 'HW-3000', purchaseDate: '2023-09-01', notes: 'Due for service' }
    ]);

    // Demo jobs
    this.set('jobs', [
      { id: 'j1', type: 'residential', status: 'completed', title: 'Driveway Pressure Wash + Nano Ceramic Shield', clientId: 'c1', location: '45 Sunset Dr, Coconut Grove NT', date: yesterday, time: '08:00', assigneeId: 't3', amount: 450, services: ['pressure-wash','nano-ceramic'], surfaces: ['driveway'], notes: 'Large double driveway, easy access', completionNotes: 'Driveway cleaned and nano treatment applied. Client very happy with results.' },
      { id: 'j2', type: 'commercial', status: 'in-progress', title: 'Shopping Centre Concrete Cleaning', clientId: 'c4', location: '18 Temple Tce, Palmerston NT', date: today, time: '06:00', assigneeId: 't3', amount: 1200, services: ['pressure-wash'], surfaces: ['concrete'], notes: 'After hours - start 6am' },
      { id: 'j3', type: 'residential', status: 'scheduled', title: 'Pool Surround & Patio Cleaning', clientId: 'c5', location: '8 Casuarina Dr, Nightcliff NT', date: today, time: '14:00', assigneeId: 't4', amount: 380, services: ['pressure-wash','nano-ceramic'], surfaces: ['pool','patio'], notes: 'Client wants nano upgrade' },
      { id: 'j4', type: 'commercial', status: 'scheduled', title: 'School Amenity Block Deep Clean', clientId: 'c3', location: '93 Bullocky Point Rd, Darwin NT', date: tomorrow, time: '07:00', assigneeId: 't3', amount: 850, services: ['pressure-wash','anti-mould'], surfaces: ['walls','concrete'], notes: 'School holidays - full access' },
      { id: 'j5', type: 'residential', status: 'scheduled', title: 'Exterior Walls + Roof Clean', clientId: 'c1', location: '45 Sunset Dr, Coconut Grove NT', date: tomorrow, time: '09:00', assigneeId: 't4', amount: 650, services: ['pressure-wash'], surfaces: ['walls','roof'], notes: '2 storey house, safety harness required' },
      { id: 'j6', type: 'commercial', status: 'completed', title: 'Office Building Entry & Pathways', clientId: 'c2', location: '12 Cavenagh St, Darwin CBD NT', date: yesterday, time: '17:00', assigneeId: 't3', amount: 550, services: ['pressure-wash'], surfaces: ['pathway','concrete'], notes: 'After business hours', completionNotes: 'All pathways cleaned. Client signed off.' }
    ]);

    // Demo checklists
    this.set('checklists', [
      {
        id: 'cl1', title: 'Pre-Job Safety Check', category: 'safety', items: [
          { id: 'cl1i1', text: 'PPE checked - boots, gloves, eye protection', done: true },
          { id: 'cl1i2', text: 'Equipment inspected for damage', done: true },
          { id: 'cl1i3', text: 'Hoses and connections secure', done: false },
          { id: 'cl1i4', text: 'Site hazards identified and marked', done: false },
          { id: 'cl1i5', text: 'Water source confirmed and tested', done: false }
        ]
      },
      {
        id: 'cl2', title: 'Nano Treatment Procedure', category: 'procedure', items: [
          { id: 'cl2i1', text: 'Surface fully cleaned and dry', done: true },
          { id: 'cl2i2', text: 'Temperature check - between 10-35°C', done: true },
          { id: 'cl2i3', text: 'Nano solution mixed per instructions', done: false },
          { id: 'cl2i4', text: 'Even application with microfibre', done: false },
          { id: 'cl2i5', text: 'Cure time observed (24h no water)', done: false }
        ]
      },
      {
        id: 'cl3', title: 'End of Day Vehicle Check', category: 'vehicle', items: [
          { id: 'cl3i1', text: 'Equipment loaded and secured', done: false },
          { id: 'cl3i2', text: 'Chemicals stored properly', done: false },
          { id: 'cl3i3', text: 'Fuel level checked', done: false },
          { id: 'cl3i4', text: 'Vehicle cleaned inside', done: false }
        ]
      }
    ]);
  }
};

// ============================================================
// APP STATE
// ============================================================
let currentUser = null;
let currentSection = 'overview';
let selectedJobId = null;

// ============================================================
// INITIALIZATION
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
  DB.init();
  checkLogin();
  updateGreeting();
  setInterval(updateGreeting, 60000); // Update greeting every minute
  
  // Check for auto-login
  const saved = DB.get('currentUser');
  if (saved) {
    currentUser = saved;
    showDashboard();
  }
});

function checkLogin() {
  if (!currentUser) {
    document.getElementById('loginScreen').style.display = 'grid';
    document.getElementById('dashboardApp').style.display = 'none';
  }
}

function doLogin() {
  const email = document.getElementById('loginEmail').value;
  const name = email.split('@')[0];
  const properName = name.charAt(0).toUpperCase() + name.slice(1);
  currentUser = { email, name: properName };
  DB.set('currentUser', currentUser);
  showDashboard();
}

function doLogout() {
  currentUser = null;
  DB.set('currentUser', null);
  document.getElementById('loginScreen').style.display = 'grid';
  document.getElementById('dashboardApp').style.display = 'none';
}

function showDashboard() {
  document.getElementById('loginScreen').style.display = 'none';
  document.getElementById('dashboardApp').style.display = 'block';
  document.getElementById('userName').textContent = currentUser.name;
  document.getElementById('userAvatar').textContent = currentUser.name.substring(0, 2).toUpperCase();
  showSection('overview');
}

function updateGreeting() {
  const hour = new Date().getHours();
  let greeting = 'Good evening';
  if (hour < 12) greeting = 'Good morning';
  else if (hour < 18) greeting = 'Good afternoon';
  
  const el = document.getElementById('overviewGreeting');
  if (el && currentUser) {
    el.textContent = greeting + ', ' + currentUser.name;
  }
  
  const dateEl = document.getElementById('overviewDate');
  if (dateEl) {
    dateEl.textContent = new Date().toLocaleDateString('en-AU', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  }
}

// ============================================================
// NAVIGATION
// ============================================================
function showSection(section) {
  currentSection = section;
  
  // Hide all sections
  document.querySelectorAll('.dash-section').forEach(s => s.classList.remove('active'));
  
  // Show target section
  const target = document.getElementById('section-' + section);
  if (target) target.classList.add('active');
  
  // Update nav buttons
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.section === section);
  });
  
  // Close user menu
  document.getElementById('userMenu').classList.remove('open');
  
  // Render section content
  switch(section) {
    case 'overview': renderOverview(); break;
    case 'jobs': renderJobs(); break;
    case 'checklists': renderChecklists(); break;
    case 'equipment': renderEquipment(); break;
    case 'clients': renderClients(); break;
    case 'team': renderTeam(); break;
    case 'reports': break; // Reports has static UI
    case 'settings': loadSettings(); break;
  }
}

function toggleUserMenu() {
  document.getElementById('userMenu').classList.toggle('open');
}

// Close menus when clicking outside
document.addEventListener('click', (e) => {
  if (!e.target.closest('.user-badge')) {
    document.getElementById('userMenu').classList.remove('open');
  }
});

// ============================================================
// OVERVIEW RENDERING
// ============================================================
function renderOverview() {
  const jobs = DB.get('jobs') || [];
  const today = new Date().toISOString().split('T')[0];
  
  // KPIs
  const completed = jobs.filter(j => j.status === 'completed');
  const pending = jobs.filter(j => j.status === 'scheduled' || j.status === 'in-progress');
  const commercial = jobs.filter(j => j.type === 'commercial');
  const residential = jobs.filter(j => j.type === 'residential');
  const nano = jobs.filter(j => j.services && j.services.includes('nano-ceramic'));
  const revenue = completed.reduce((sum, j) => sum + (parseFloat(j.amount) || 0), 0);
  
  document.getElementById('kpiRevenue').textContent = '$' + revenue.toLocaleString();
  document.getElementById('kpiCompleted').textContent = completed.length;
  document.getElementById('kpiPending').textContent = pending.length;
  document.getElementById('kpiCommercial').textContent = commercial.length;
  document.getElementById('kpiResidential').textContent = residential.length;
  document.getElementById('kpiNano').textContent = nano.length;
  
  // Badges
  const activeToday = jobs.filter(j => j.date === today && (j.status === 'scheduled' || j.status === 'in-progress')).length;
  const urgent = jobs.filter(j => j.status === 'in-progress' && !j.completionNotes).length;
  document.getElementById('badgeActiveJobs').textContent = pending.length + ' Active';
  document.getElementById('badgeToday').textContent = activeToday + ' Today';
  document.getElementById('badgeUrgent').textContent = urgent + ' Urgent';
  
  // Today's schedule
  const todaysJobs = jobs.filter(j => j.date === today).sort((a, b) => (a.time || '').localeCompare(b.time || ''));
  const scheduleContainer = document.getElementById('todaySchedule');
  if (todaysJobs.length === 0) {
    scheduleContainer.innerHTML = '<p style="color:var(--pearl-5);text-align:center;padding:20px;">No jobs scheduled for today</p>';
  } else {
    scheduleContainer.innerHTML = todaysJobs.map(job => {
      const client = getClient(job.clientId);
      return `
        <div class="schedule-item" onclick="viewJob('${job.id}')">
          <div class="schedule-time">${job.time || 'TBA'}</div>
          <div class="schedule-info">
            <h4>${job.title}</h4>
            <p>${client ? client.firstName + ' ' + client.lastName : 'Unknown'} • ${job.location || ''}</p>
          </div>
          <span class="schedule-status status-${job.status}">${job.status.replace('-', ' ')}</span>
        </div>
      `;
    }).join('');
  }
  
  // Alerts
  const alerts = [];
  const overdueEquip = (DB.get('equipment') || []).filter(e => e.status === 'repair');
  if (overdueEquip.length > 0) alerts.push({ icon: '⚠️', title: overdueEquip.length + ' equipment needs repair', time: 'Now', type: 'urgent' });
  if (urgent > 0) alerts.push({ icon: '🔵', title: urgent + ' job(s) in progress', time: 'Now', type: 'info' });
  const tomorrowJobs = jobs.filter(j => j.date === new Date(Date.now() + 86400000).toISOString().split('T')[0]);
  if (tomorrowJobs.length > 0) alerts.push({ icon: '📅', title: tomorrowJobs.length + ' job(s) tomorrow', time: 'Tomorrow', type: 'info' });
  
  document.getElementById('alertsList').innerHTML = alerts.length === 0 
    ? '<p style="color:var(--pearl-5);text-align:center;padding:20px;">No alerts</p>'
    : alerts.map(a => `
        <div class="alert-item">
          <span class="alert-icon">${a.icon}</span>
          <div class="alert-text">
            <strong>${a.title}</strong>
          </div>
          <span class="alert-time">${a.time}</span>
        </div>
      `).join('');
  
  // Quick checklists
  const checklists = DB.get('checklists') || [];
  document.getElementById('quickChecklists').innerHTML = checklists.slice(0, 3).map(cl => {
    const done = cl.items.filter(i => i.done).length;
    const pct = Math.round((done / cl.items.length) * 100);
    return `
      <div class="quick-checklist-item" onclick="showSection('checklists')">
        <span class="cl-progress">${pct}%</span>
        <label>${cl.title}</label>
      </div>
    `;
  }).join('');
  
  // Equipment status
  const equipment = DB.get('equipment') || [];
  document.getElementById('equipmentStatus').innerHTML = equipment.slice(0, 4).map(eq => {
    const statusColors = { available: 'var(--success)', 'in-use': 'var(--aqua-7)', maintenance: 'var(--warn)', repair: 'var(--danger)' };
    const icons = { 'pressure-washer': '💦', 'surface-cleaner': '🌀', vehicle: '🚗', chemical: '🧪', tool: '🔧', safety: '⛑️', trailer: '🚛' };
    return `
      <div class="equip-card">
        <div class="equip-icon">${icons[eq.type] || '🔧'}</div>
        <h4>${eq.name}</h4>
        <span class="equip-status" style="background:${statusColors[eq.status]}22;color:${statusColors[eq.status]}">${eq.status}</span>
      </div>
    `;
  }).join('');
}

// ============================================================
// JOB MANAGEMENT
// ============================================================
function renderJobs() {
  const jobs = DB.get('jobs') || [];
  const filterType = document.getElementById('jobFilterType')?.value || 'all';
  const filterStatus = document.getElementById('jobFilterStatus')?.value || 'all';
  
  let filtered = jobs;
  if (filterType !== 'all') filtered = filtered.filter(j => j.type === filterType);
  if (filterStatus !== 'all') filtered = filtered.filter(j => j.status === filterStatus);
  
  const container = document.getElementById('jobsList');
  if (filtered.length === 0) {
    container.innerHTML = '<p style="color:var(--pearl-5);text-align:center;padding:40px;">No jobs found</p>';
    return;
  }
  
  container.innerHTML = filtered.map(job => {
    const client = getClient(job.clientId);
    const assignee = getTeamMember(job.assigneeId);
    return `
      <div class="job-card ${job.type} ${job.status}" onclick="viewJob('${job.id}')">
        <div class="job-info">
          <h3>${job.title}</h3>
          <div class="job-meta">
            <span>📅 ${formatDate(job.date)} ${job.time ? '@ ' + job.time : ''}</span>
            <span>👤 ${client ? client.firstName + ' ' + client.lastName : 'No client'}</span>
            ${assignee ? `<span>🧑‍🔧 ${assignee.firstName}</span>` : ''}
            <span>📍 ${job.location || 'No location'}</span>
          </div>
          <div class="job-badges">
            <span class="job-badge job-badge-${job.type}">${job.type}</span>
            ${job.services?.includes('nano-ceramic') ? '<span class="job-badge job-badge-nano">Nano</span>' : ''}
          </div>
        </div>
        <div class="job-actions">
          <span class="job-amount">$${job.amount || 0}</span>
        </div>
      </div>
    `;
  }).join('');
}

function openNewJob() {
  selectedJobId = null;
  document.getElementById('jobModalTitle').textContent = 'New Job';
  document.getElementById('jobId').value = '';
  document.getElementById('jobType').value = 'residential';
  document.getElementById('jobStatus').value = 'scheduled';
  document.getElementById('jobTitle').value = '';
  document.getElementById('jobLocation').value = '';
  document.getElementById('jobDate').value = new Date().toISOString().split('T')[0];
  document.getElementById('jobTime').value = '08:00';
  document.getElementById('jobAmount').value = '';
  document.getElementById('jobNotes').value = '';
  document.getElementById('jobCompletionNotes').value = '';
  document.getElementById('completionFields').style.display = 'none';
  
  // Reset checkboxes
  document.querySelectorAll('.checkbox-group input[type="checkbox"]').forEach(cb => cb.checked = false);
  
  populateClientSelect();
  populateTeamSelect();
  openModal('modalJob');
}

function saveJob() {
  const id = document.getElementById('jobId').value || 'j' + Date.now();
  const services = [];
  if (document.getElementById('svcPressure').checked) services.push('pressure-wash');
  if (document.getElementById('svcNano').checked) services.push('nano-ceramic');
  if (document.getElementById('svcAntiGraffiti').checked) services.push('anti-graffiti');
  if (document.getElementById('svcAntiMould').checked) services.push('anti-mould');
  if (document.getElementById('svcInspection').checked) services.push('inspection');
  
  const surfaces = [];
  if (document.getElementById('surfDriveway').checked) surfaces.push('driveway');
  if (document.getElementById('surfPathway').checked) surfaces.push('pathway');
  if (document.getElementById('surfPatio').checked) surfaces.push('patio');
  if (document.getElementById('surfPool').checked) surfaces.push('pool');
  if (document.getElementById('surfWalls').checked) surfaces.push('walls');
  if (document.getElementById('surfConcrete').checked) surfaces.push('concrete');
  if (document.getElementById('surfRoof').checked) surfaces.push('roof');
  if (document.getElementById('surfFence').checked) surfaces.push('fence');
  
  const job = {
    id,
    type: document.getElementById('jobType').value,
    status: document.getElementById('jobStatus').value,
    title: document.getElementById('jobTitle').value,
    clientId: document.getElementById('jobClient').value,
    location: document.getElementById('jobLocation').value,
    date: document.getElementById('jobDate').value,
    time: document.getElementById('jobTime').value,
    assigneeId: document.getElementById('jobAssignee').value,
    amount: parseFloat(document.getElementById('jobAmount').value) || 0,
    services,
    surfaces,
    notes: document.getElementById('jobNotes').value,
    completionNotes: document.getElementById('jobCompletionNotes').value
  };
  
  const jobs = DB.get('jobs') || [];
  const idx = jobs.findIndex(j => j.id === id);
  if (idx >= 0) jobs[idx] = job;
  else jobs.push(job);
  DB.set('jobs', jobs);
  
  closeModal('modalJob');
  renderJobs();
  renderOverview();
}

function viewJob(jobId) {
  const jobs = DB.get('jobs') || [];
  const job = jobs.find(j => j.id === jobId);
  if (!job) return;
  
  selectedJobId = jobId;
  const client = getClient(job.clientId);
  const assignee = getTeamMember(job.assigneeId);
  
  document.getElementById('jobDetailTitle').textContent = job.title;
  document.getElementById('jobDetailBody').innerHTML = `
    <div class="job-detail-grid">
      <div class="detail-group">
        <label>Job Type</label>
        <span class="job-badge job-badge-${job.type}">${job.type}</span>
      </div>
      <div class="detail-group">
        <label>Status</label>
        <span class="schedule-status status-${job.status}">${job.status.replace('-', ' ')}</span>
      </div>
      <div class="detail-group">
        <label>Client</label>
        <p>${client ? client.firstName + ' ' + client.lastName : 'N/A'}</p>
        ${client?.phone ? `<p>📞 ${client.phone}</p>` : ''}
        ${client?.email ? `<p>✉️ ${client.email}</p>` : ''}
      </div>
      <div class="detail-group">
        <label>Location</label>
        <p>📍 ${job.location || 'N/A'}</p>
      </div>
      <div class="detail-group">
        <label>Schedule</label>
        <p>📅 ${formatDate(job.date)} @ ${job.time || 'TBA'}</p>
      </div>
      <div class="detail-group">
        <label>Assigned To</label>
        <p>${assignee ? assignee.firstName + ' ' + assignee.lastName : 'Unassigned'}</p>
      </div>
      <div class="detail-group">
        <label>Amount</label>
        <p class="job-amount">$${job.amount || 0}</p>
      </div>
      <div class="detail-group">
        <label>Services</label>
        <p>${job.services?.map(s => serviceName(s)).join(', ') || 'None'}</p>
      </div>
      <div class="detail-group" style="grid-column:1/-1">
        <label>Surfaces</label>
        <div class="surface-tags">${job.surfaces?.map(s => `<span class="surface-tag">${s}</span>`).join('') || 'None'}</div>
      </div>
      ${job.notes ? `<div class="detail-group" style="grid-column:1/-1"><label>Notes</label><p style="color:var(--pearl-6)">${job.notes}</p></div>` : ''}
      ${job.completionNotes ? `<div class="detail-group" style="grid-column:1/-1"><label>Completion Notes</label><p style="color:var(--success)">${job.completionNotes}</p></div>` : ''}
    </div>
  `;
  
  const actionBtn = document.getElementById('jobDetailActionBtn');
  if (job.status === 'completed') {
    actionBtn.textContent = 'Edit Job';
    actionBtn.onclick = () => { closeModal('modalJobDetail'); editJob(jobId); };
  } else {
    actionBtn.textContent = 'Mark Complete';
    actionBtn.onclick = completeJobFromDetail;
  }
  
  openModal('modalJobDetail');
}

function editJob(jobId) {
  const jobs = DB.get('jobs') || [];
  const job = jobs.find(j => j.id === jobId);
  if (!job) return;
  
  selectedJobId = jobId;
  document.getElementById('jobModalTitle').textContent = 'Edit Job';
  document.getElementById('jobId').value = job.id;
  document.getElementById('jobType').value = job.type;
  document.getElementById('jobStatus').value = job.status;
  document.getElementById('jobTitle').value = job.title;
  document.getElementById('jobLocation').value = job.location || '';
  document.getElementById('jobDate').value = job.date;
  document.getElementById('jobTime').value = job.time || '';
  document.getElementById('jobAmount').value = job.amount || '';
  document.getElementById('jobNotes').value = job.notes || '';
  document.getElementById('jobCompletionNotes').value = job.completionNotes || '';
  document.getElementById('completionFields').style.display = 'block';
  
  populateClientSelect(job.clientId);
  populateTeamSelect(job.assigneeId);
  
  // Checkboxes
  document.getElementById('svcPressure').checked = job.services?.includes('pressure-wash') || false;
  document.getElementById('svcNano').checked = job.services?.includes('nano-ceramic') || false;
  document.getElementById('svcAntiGraffiti').checked = job.services?.includes('anti-graffiti') || false;
  document.getElementById('svcAntiMould').checked = job.services?.includes('anti-mould') || false;
  document.getElementById('svcInspection').checked = job.services?.includes('inspection') || false;
  
  document.getElementById('surfDriveway').checked = job.surfaces?.includes('driveway') || false;
  document.getElementById('surfPathway').checked = job.surfaces?.includes('pathway') || false;
  document.getElementById('surfPatio').checked = job.surfaces?.includes('patio') || false;
  document.getElementById('surfPool').checked = job.surfaces?.includes('pool') || false;
  document.getElementById('surfWalls').checked = job.surfaces?.includes('walls') || false;
  document.getElementById('surfConcrete').checked = job.surfaces?.includes('concrete') || false;
  document.getElementById('surfRoof').checked = job.surfaces?.includes('roof') || false;
  document.getElementById('surfFence').checked = job.surfaces?.includes('fence') || false;
  
  openModal('modalJob');
}

function completeJobFromDetail() {
  const jobs = DB.get('jobs') || [];
  const idx = jobs.findIndex(j => j.id === selectedJobId);
  if (idx >= 0) {
    jobs[idx].status = 'completed';
    if (!jobs[idx].completionNotes) {
      jobs[idx].completionNotes = 'Job completed successfully.';
    }
    DB.set('jobs', jobs);
  }
  closeModal('modalJobDetail');
  renderJobs();
  renderOverview();
}

function populateClientSelect(selectedId) {
  const clients = DB.get('clients') || [];
  const select = document.getElementById('jobClient');
  select.innerHTML = '<option value="">Select client...</option>' + 
    clients.map(c => `<option value="${c.id}" ${c.id === selectedId ? 'selected' : ''}>${c.firstName} ${c.lastName}</option>`).join('');
}

function populateTeamSelect(selectedId) {
  const team = DB.get('team') || [];
  const select = document.getElementById('jobAssignee');
  select.innerHTML = '<option value="">Unassigned</option>' + 
    team.map(t => `<option value="${t.id}" ${t.id === selectedId ? 'selected' : ''}>${t.firstName} ${t.lastName}</option>`).join('');
}

function toggleJobFields() {
  // Could add logic to show/hide fields based on job type
}

// ============================================================
// CLIENT MANAGEMENT
// ============================================================
function renderClients() {
  const clients = DB.get('clients') || [];
  const container = document.getElementById('clientsList');
  
  if (clients.length === 0) {
    container.innerHTML = '<p style="color:var(--pearl-5);text-align:center;padding:40px;">No clients yet</p>';
    return;
  }
  
  container.innerHTML = clients.map(c => `
    <div class="client-card">
      <h3>${c.firstName} ${c.lastName}</h3>
      <p>📞 ${c.phone || 'No phone'}</p>
      <p>✉️ ${c.email || 'No email'}</p>
      <p>📍 ${c.address || 'No address'}</p>
      <span class="client-type client-type-${c.type}">${c.type}</span>
    </div>
  `).join('');
}

function openNewClient() {
  document.getElementById('clientId').value = '';
  document.getElementById('clientFirstName').value = '';
  document.getElementById('clientLastName').value = '';
  document.getElementById('clientPhone').value = '';
  document.getElementById('clientEmail').value = '';
  document.getElementById('clientAddress').value = '';
  document.getElementById('clientType').value = 'residential';
  document.getElementById('clientNotes').value = '';
  openModal('modalClient');
}

function saveClient() {
  const id = document.getElementById('clientId').value || 'c' + Date.now();
  const client = {
    id,
    firstName: document.getElementById('clientFirstName').value,
    lastName: document.getElementById('clientLastName').value,
    phone: document.getElementById('clientPhone').value,
    email: document.getElementById('clientEmail').value,
    address: document.getElementById('clientAddress').value,
    type: document.getElementById('clientType').value,
    notes: document.getElementById('clientNotes').value
  };
  
  const clients = DB.get('clients') || [];
  const idx = clients.findIndex(c => c.id === id);
  if (idx >= 0) clients[idx] = client;
  else clients.push(client);
  DB.set('clients', clients);
  
  closeModal('modalClient');
  renderClients();
}

// ============================================================
// TEAM MANAGEMENT
// ============================================================
function renderTeam() {
  const team = DB.get('team') || [];
  const container = document.getElementById('teamList');
  
  if (team.length === 0) {
    container.innerHTML = '<p style="color:var(--pearl-5);text-align:center;padding:40px;">No team members yet</p>';
    return;
  }
  
  container.innerHTML = team.map(t => `
    <div class="team-card">
      <h3>${t.firstName} ${t.lastName}</h3>
      <p>📞 ${t.phone || 'No phone'}</p>
      <p>✉️ ${t.email || 'No email'}</p>
      <span class="team-role" style="background:rgba(200,168,64,.1);color:var(--gold-6)">${t.role}</span>
    </div>
  `).join('');
}

function openNewTeamMember() {
  document.getElementById('teamId').value = '';
  document.getElementById('teamFirstName').value = '';
  document.getElementById('teamLastName').value = '';
  document.getElementById('teamPhone').value = '';
  document.getElementById('teamEmail').value = '';
  document.getElementById('teamRole').value = 'Operator';
  document.getElementById('teamNotes').value = '';
  openModal('modalTeam');
}

function saveTeamMember() {
  const id = document.getElementById('teamId').value || 't' + Date.now();
  const member = {
    id,
    firstName: document.getElementById('teamFirstName').value,
    lastName: document.getElementById('teamLastName').value,
    phone: document.getElementById('teamPhone').value,
    email: document.getElementById('teamEmail').value,
    role: document.getElementById('teamRole').value,
    notes: document.getElementById('teamNotes').value
  };
  
  const team = DB.get('team') || [];
  const idx = team.findIndex(t => t.id === id);
  if (idx >= 0) team[idx] = member;
  else team.push(member);
  DB.set('team', team);
  
  closeModal('modalTeam');
  renderTeam();
}

// ============================================================
// EQUIPMENT MANAGEMENT
// ============================================================
function renderEquipment() {
  const equipment = DB.get('equipment') || [];
  const container = document.getElementById('equipmentList');
  
  if (equipment.length === 0) {
    container.innerHTML = '<p style="color:var(--pearl-5);text-align:center;padding:40px;">No equipment yet</p>';
    return;
  }
  
  const statusColors = { available: 'var(--success)', 'in-use': 'var(--aqua-7)', maintenance: 'var(--warn)', repair: 'var(--danger)' };
  
  container.innerHTML = equipment.map(eq => `
    <div class="equipment-item">
      <h3>${eq.name}</h3>
      <p>🔧 ${eq.model || 'No model'}</p>
      <p>Type: ${eq.type}</p>
      <span style="display:inline-block;padding:4px 12px;border-radius:999px;font-size:.8rem;font-weight:800;background:${statusColors[eq.status]}22;color:${statusColors[eq.status]}">${eq.status}</span>
    </div>
  `).join('');
}

function openNewEquipment() {
  document.getElementById('equipId').value = '';
  document.getElementById('equipName').value = '';
  document.getElementById('equipType').value = 'pressure-washer';
  document.getElementById('equipStatus').value = 'available';
  document.getElementById('equipModel').value = '';
  document.getElementById('equipPurchaseDate').value = '';
  document.getElementById('equipNotes').value = '';
  openModal('modalEquipment');
}

function saveEquipment() {
  const id = document.getElementById('equipId').value || 'e' + Date.now();
  const equip = {
    id,
    name: document.getElementById('equipName').value,
    type: document.getElementById('equipType').value,
    status: document.getElementById('equipStatus').value,
    model: document.getElementById('equipModel').value,
    purchaseDate: document.getElementById('equipPurchaseDate').value,
    notes: document.getElementById('equipNotes').value
  };
  
  const equipment = DB.get('equipment') || [];
  const idx = equipment.findIndex(e => e.id === id);
  if (idx >= 0) equipment[idx] = equip;
  else equipment.push(equip);
  DB.set('equipment', equipment);
  
  closeModal('modalEquipment');
  renderEquipment();
  renderOverview();
}

// ============================================================
// CHECKLISTS
// ============================================================
function renderChecklists() {
  const checklists = DB.get('checklists') || [];
  const container = document.getElementById('checklistsContainer');
  
  if (checklists.length === 0) {
    container.innerHTML = '<p style="color:var(--pearl-5);text-align:center;padding:40px;">No checklists yet</p>';
    return;
  }
  
  container.innerHTML = checklists.map(cl => {
    const done = cl.items.filter(i => i.done).length;
    const pct = Math.round((done / cl.items.length) * 100);
    return `
      <div class="checklist-card">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
          <h3>${cl.title}</h3>
          <span style="color:var(--gold-6);font-weight:800">${pct}%</span>
        </div>
        <div class="checklist-items">
          ${cl.items.map((item, idx) => `
            <div class="checklist-item-row ${item.done ? 'checked' : ''}">
              <input type="checkbox" ${item.done ? 'checked' : ''} onchange="toggleChecklistItem('${cl.id}', ${idx})" id="${cl.id}_${idx}" />
              <label for="${cl.id}_${idx}">${item.text}</label>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }).join('');
}

function toggleChecklistItem(checklistId, itemIdx) {
  const checklists = DB.get('checklists') || [];
  const cl = checklists.find(c => c.id === checklistId);
  if (cl && cl.items[itemIdx]) {
    cl.items[itemIdx].done = !cl.items[itemIdx].done;
    DB.set('checklists', checklists);
    renderChecklists();
    renderOverview();
  }
}

function openNewChecklist() {
  const title = prompt('Checklist title:');
  if (!title) return;
  
  const checklists = DB.get('checklists') || [];
  checklists.push({
    id: 'cl' + Date.now(),
    title,
    category: 'general',
    items: [
      { id: 'item1', text: 'Item 1', done: false },
      { id: 'item2', text: 'Item 2', done: false }
    ]
  });
  DB.set('checklists', checklists);
  renderChecklists();
}

// ============================================================
// REPORT GENERATION
// ============================================================
function generateDailyReport() {
  const today = new Date().toISOString().split('T')[0];
  const jobs = (DB.get('jobs') || []).filter(j => j.date === today);
  const completed = jobs.filter(j => j.status === 'completed');
  const pending = jobs.filter(j => j.status === 'scheduled' || j.status === 'in-progress');
  const settings = DB.get('settings') || {};
  
  const reportHTML = `
    <div class="report-header">
      <h2>📊 Daily Operations Report</h2>
      <p>${new Date().toLocaleDateString('en-AU', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
      <p style="color:var(--gold-6);font-weight:800">${settings.bizName || "Sam's Pro-Wash Solutions"}</p>
    </div>
    
    <div class="report-summary">
      <div class="report-summary-box">
        <span class="num">${jobs.length}</span>
        <span class="label">Total Jobs</span>
      </div>
      <div class="report-summary-box">
        <span class="num">${completed.length}</span>
        <span class="label">Completed</span>
      </div>
      <div class="report-summary-box">
        <span class="num">${pending.length}</span>
        <span class="label">Pending</span>
      </div>
      <div class="report-summary-box">
        <span class="num">$${completed.reduce((s, j) => s + (parseFloat(j.amount) || 0), 0)}</span>
        <span class="label">Revenue</span>
      </div>
    </div>
    
    <div class="report-section">
      <h3>Today's Jobs</h3>
      ${jobs.length === 0 ? '<p style="color:var(--pearl-5)">No jobs scheduled for today.</p>' : `
        <table class="report-table">
          <thead><tr><th>Time</th><th>Job</th><th>Client</th><th>Type</th><th>Status</th><th>Amount</th></tr></thead>
          <tbody>
            ${jobs.map(job => {
              const client = getClient(job.clientId);
              return `<tr>
                <td>${job.time || 'TBA'}</td>
                <td>${job.title}</td>
                <td>${client ? client.firstName + ' ' + client.lastName : 'N/A'}</td>
                <td>${job.type}</td>
                <td>${job.status}</td>
                <td>$${job.amount || 0}</td>
              </tr>`;
            }).join('')}
          </tbody>
        </table>
      `}
    </div>
    
    <div class="report-section">
      <h3>Completed Job Details</h3>
      ${completed.length === 0 ? '<p style="color:var(--pearl-5)">No jobs completed yet today.</p>' : 
        completed.map(job => {
          const client = getClient(job.clientId);
          return `
            <div style="background:rgba(255,255,255,.02);border:var(--border-pearl);border-radius:16px;padding:20px;margin-bottom:16px">
              <h4 style="color:var(--gold-6);margin:0 0 8px">${job.title}</h4>
              <p style="color:var(--pearl-6);margin:0 0 4px"><strong>Client:</strong> ${client ? client.firstName + ' ' + client.lastName : 'N/A'}</p>
              <p style="color:var(--pearl-6);margin:0 0 4px"><strong>Location:</strong> ${job.location || 'N/A'}</p>
              <p style="color:var(--pearl-6);margin:0 0 4px"><strong>Services:</strong> ${job.services?.map(s => serviceName(s)).join(', ') || 'N/A'}</p>
              <p style="color:var(--pearl-6);margin:0 0 4px"><strong>Surfaces:</strong> ${job.surfaces?.join(', ') || 'N/A'}</p>
              <p style="color:var(--pearl-6);margin:0 0 4px"><strong>Amount:</strong> $${job.amount || 0}</p>
              ${job.completionNotes ? `<p style="color:var(--success);margin:8px 0 0"><strong>Completion Notes:</strong> ${job.completionNotes}</p>` : ''}
            </div>
          `;
        }).join('')
      }
    </div>
    
    <div class="report-section">
      <h3>Equipment Status</h3>
      <table class="report-table">
        <thead><tr><th>Equipment</th><th>Type</th><th>Status</th></tr></thead>
        <tbody>
          ${(DB.get('equipment') || []).map(eq => `
            <tr><td>${eq.name}</td><td>${eq.type}</td><td>${eq.status}</td></tr>
          `).join('')}
        </tbody>
      </table>
    </div>
    
    <div style="text-align:center;margin-top:32px;padding-top:24px;border-top:var(--border-pearl);color:var(--pearl-4);font-size:.9rem">
      <p>Generated by Sam's Pro-Wash Command Centre</p>
      <p>${settings.bizPhone || '0455 581 715'} | ${settings.bizAddress || 'Darwin, NT'}</p>
    </div>
  `;
  
  document.getElementById('reportModalTitle').textContent = 'Daily Report';
  document.getElementById('reportContent').innerHTML = reportHTML;
  openModal('modalReport');
}

function generateWeeklyReport() {
  const now = new Date();
  const weekStart = new Date(now - now.getDay() * 86400000);
  const weekJobs = (DB.get('jobs') || []).filter(j => new Date(j.date) >= weekStart);
  const completed = weekJobs.filter(j => j.status === 'completed');
  const settings = DB.get('settings') || {};
  
  const reportHTML = `
    <div class="report-header">
      <h2>📈 Weekly Operations Report</h2>
      <p>Week of ${weekStart.toLocaleDateString('en-AU', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
      <p style="color:var(--gold-6);font-weight:800">${settings.bizName || "Sam's Pro-Wash Solutions"}</p>
    </div>
    
    <div class="report-summary">
      <div class="report-summary-box">
        <span class="num">${weekJobs.length}</span>
        <span class="label">Total Jobs</span>
      </div>
      <div class="report-summary-box">
        <span class="num">${completed.length}</span>
        <span class="label">Completed</span>
      </div>
      <div class="report-summary-box">
        <span class="num">${weekJobs.filter(j => j.type === 'commercial').length}</span>
        <span class="label">Commercial</span>
      </div>
      <div class="report-summary-box">
        <span class="num">$${completed.reduce((s, j) => s + (parseFloat(j.amount) || 0), 0)}</span>
        <span class="label">Revenue</span>
      </div>
    </div>
    
    <div class="report-section">
      <h3>Weekly Job Breakdown</h3>
      <table class="report-table">
        <thead><tr><th>Date</th><th>Job</th><th>Client</th><th>Type</th><th>Status</th><th>Amount</th></tr></thead>
        <tbody>
          ${weekJobs.map(job => {
            const client = getClient(job.clientId);
            return `<tr>
              <td>${formatDate(job.date)}</td>
              <td>${job.title}</td>
              <td>${client ? client.firstName + ' ' + client.lastName : 'N/A'}</td>
              <td>${job.type}</td>
              <td>${job.status}</td>
              <td>$${job.amount || 0}</td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>
  `;
  
  document.getElementById('reportModalTitle').textContent = 'Weekly Report';
  document.getElementById('reportContent').innerHTML = reportHTML;
  openModal('modalReport');
}

function generateJobReport() {
  const jobId = prompt('Enter Job ID (or leave blank for last completed job):');
  const jobs = DB.get('jobs') || [];
  let job;
  
  if (jobId) {
    job = jobs.find(j => j.id === jobId);
  } else {
    job = jobs.filter(j => j.status === 'completed').sort((a, b) => new Date(b.date) - new Date(a.date))[0];
  }
  
  if (!job) {
    alert('No completed jobs found!');
    return;
  }
  
  generateJobReportContent(job);
}

function generateJobReportFromDetail() {
  const jobs = DB.get('jobs') || [];
  const job = jobs.find(j => j.id === selectedJobId);
  if (job) generateJobReportContent(job);
}

function generateJobReportContent(job) {
  const client = getClient(job.clientId);
  const settings = DB.get('settings') || {};
  
  const reportHTML = `
    <div class="report-header">
      <h2>✅ Job Completion Report</h2>
      <p style="color:var(--gold-6);font-weight:800;font-size:1.2rem">${settings.bizName || "Sam's Pro-Wash Solutions"}</p>
      <p>Luxury Surface Protection & Pressure Washing</p>
    </div>
    
    <div style="background:linear-gradient(135deg,rgba(200,168,64,.08),rgba(0,224,232,.04));border:var(--border-glow);border-radius:20px;padding:24px;margin-bottom:24px">
      <h3 style="color:var(--gold-6);margin:0 0 16px;font-size:1.3rem">${job.title}</h3>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
        <div>
          <p style="color:var(--pearl-5);margin:0 0 4px;font-size:.9rem"><strong style="color:var(--pearl-8)">Client:</strong> ${client ? client.firstName + ' ' + client.lastName : 'N/A'}</p>
          <p style="color:var(--pearl-5);margin:0 0 4px;font-size:.9rem"><strong style="color:var(--pearl-8)">Address:</strong> ${job.location || 'N/A'}</p>
          <p style="color:var(--pearl-5);margin:0 0 4px;font-size:.9rem"><strong style="color:var(--pearl-8)">Date Completed:</strong> ${formatDate(job.date)}</p>
        </div>
        <div>
          <p style="color:var(--pearl-5);margin:0 0 4px;font-size:.9rem"><strong style="color:var(--pearl-8)">Job Type:</strong> ${job.type === 'residential' ? '🏠 Residential' : '🏢 Commercial'}</p>
          <p style="color:var(--pearl-5);margin:0 0 4px;font-size:.9rem"><strong style="color:var(--pearl-8)">Total Amount:</strong> <span style="color:var(--gold-6);font-size:1.2rem;font-weight:1000">$${job.amount || 0}</span></p>
          <p style="color:var(--pearl-5);margin:0 0 4px;font-size:.9rem"><strong style="color:var(--pearl-8)">Invoice #:</strong> INV-${job.id.toUpperCase()}</p>
        </div>
      </div>
    </div>
    
    <div class="report-section">
      <h3>Services Provided</h3>
      <div style="display:flex;flex-wrap:wrap;gap:10px">
        ${job.services?.map(s => `
          <span style="padding:10px 20px;border-radius:999px;background:linear-gradient(135deg,rgba(200,168,64,.12),rgba(0,224,232,.08));border:var(--border-glow);color:var(--gold-6);font-weight:800">${serviceName(s)}</span>
        `).join('') || '<p style="color:var(--pearl-5)">No services recorded</p>'}
      </div>
    </div>
    
    <div class="report-section">
      <h3>Surfaces Treated</h3>
      <div style="display:flex;flex-wrap:wrap;gap:10px">
        ${job.surfaces?.map(s => `
          <span style="padding:8px 16px;border-radius:999px;background:rgba(0,224,232,.1);border:1px solid rgba(0,224,232,.2);color:var(--aqua-7);font-weight:700">${s}</span>
        `).join('') || '<p style="color:var(--pearl-5)">No surfaces recorded</p>'}
      </div>
    </div>
    
    <div class="report-section">
      <h3>Work Performed</h3>
      <div style="background:rgba(255,255,255,.02);border:var(--border-pearl);border-radius:16px;padding:20px">
        <p style="color:var(--pearl-7);line-height:1.7;margin:0">${job.completionNotes || job.notes || 'No completion notes recorded.'}</p>
      </div>
    </div>
    
    <div class="report-section">
      <h3>Quality Assurance</h3>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px">
        <div style="text-align:center;padding:20px;background:rgba(0,192,128,.08);border:1px solid rgba(0,192,128,.2);border-radius:16px">
          <div style="font-size:2rem;margin-bottom:8px">✓</div>
          <div style="color:var(--success);font-weight:800">Surface Cleaned</div>
        </div>
        <div style="text-align:center;padding:20px;background:rgba(0,192,128,.08);border:1px solid rgba(0,192,128,.2);border-radius:16px">
          <div style="font-size:2rem;margin-bottom:8px">✓</div>
          <div style="color:var(--success);font-weight:800">Treatment Applied</div>
        </div>
        <div style="text-align:center;padding:20px;background:rgba(0,192,128,.08);border:1px solid rgba(0,192,128,.2);border-radius:16px">
          <div style="font-size:2rem;margin-bottom:8px">✓</div>
          <div style="color:var(--success);font-weight:800">Client Approved</div>
        </div>
      </div>
    </div>
    
    <div style="text-align:center;margin-top:32px;padding:24px;background:linear-gradient(135deg,rgba(200,168,64,.05),rgba(0,224,232,.03));border:var(--border-glow);border-radius:20px">
      <p style="color:var(--gold-6);font-weight:900;font-size:1.1rem;margin:0 0 8px">Thank you for choosing Sam's Pro-Wash Solutions</p>
      <p style="color:var(--pearl-5);margin:0 0 4px">Premium Pressure Washing & Nano Surface Protection</p>
      <p style="color:var(--pearl-5);margin:0">📞 ${settings.bizPhone || '0455 581 715'} | 🌐 samsprowash.com</p>
    </div>
  `;
  
  document.getElementById('reportModalTitle').textContent = 'Job Completion Report';
  document.getElementById('reportContent').innerHTML = reportHTML;
  openModal('modalReport');
}

function showReportPreview() {
  generateDailyReport();
}

function closeReportPreview() {
  document.getElementById('reportPreviewPanel').style.display = 'none';
}

function emailReport() {
  const settings = DB.get('settings') || {};
  const subject = document.getElementById('reportModalTitle').textContent + ' - ' + new Date().toLocaleDateString('en-AU');
  const body = 'Please find the attached report.\n\nGenerated by Sam\'s Pro-Wash Command Centre.\n\nView the full report in your dashboard.';
  
  window.location.href = `mailto:${settings.reportEmail || 'samsprowashsolutions@gmail.com'}?cc=${settings.reportEmailCC || ''}&subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

function printReport() {
  const content = document.getElementById('reportContent').innerHTML;
  const w = window.open('', '_blank');
  w.document.write(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Sam's Pro-Wash Report</title>
      <style>
        body{font-family:Inter,Arial,sans-serif;background:#0a0a12;color:#f0f0f8;padding:40px;max-width:800px;margin:0 auto}
        h2{color:#e0c058}h3{color:#00e0e8;border-left:4px solid #00e0e8;padding-left:12px}
        table{width:100%;border-collapse:collapse;margin:16px 0}
        th{background:rgba(200,168,64,.1);color:#e0c058;padding:12px;text-align:left}
        td{padding:12px;border-bottom:1px solid rgba(255,255,255,.1);color:#aaaab8}
        .summary{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin:24px 0}
        .box{background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:20px;text-align:center}
        .box .num{font-size:1.8rem;font-weight:bold;color:#e0c058}
        .box .label{color:#8a8aa0;font-size:.8rem}
      </style>
    </head>
    <body>${content}</body>
    </html>
  `);
  w.document.close();
  w.print();
}

// ============================================================
// SETTINGS
// ============================================================
function loadSettings() {
  const settings = DB.get('settings') || {};
  document.getElementById('reportEmail').value = settings.reportEmail || '';
  document.getElementById('reportEmailCC').value = settings.reportEmailCC || '';
  document.getElementById('reportTime').value = settings.reportTime || '18:00';
  document.getElementById('autoSendReports').checked = settings.autoSend !== false;
  document.getElementById('bizName').value = settings.bizName || '';
  document.getElementById('bizPhone').value = settings.bizPhone || '';
  document.getElementById('bizABN').value = settings.bizABN || '';
  document.getElementById('bizAddress').value = settings.bizAddress || '';
}

function saveSettings() {
  const settings = {
    reportEmail: document.getElementById('reportEmail').value,
    reportEmailCC: document.getElementById('reportEmailCC').value,
    reportTime: document.getElementById('reportTime').value,
    autoSend: document.getElementById('autoSendReports').checked,
    bizName: document.getElementById('bizName').value,
    bizPhone: document.getElementById('bizPhone').value,
    bizABN: document.getElementById('bizABN').value,
    bizAddress: document.getElementById('bizAddress').value
  };
  DB.set('settings', settings);
  alert('Settings saved!');
}

// ============================================================
// DATA EXPORT/IMPORT
// ============================================================
function exportAllData() {
  const data = {
    jobs: DB.get('jobs'),
    clients: DB.get('clients'),
    team: DB.get('team'),
    equipment: DB.get('equipment'),
    checklists: DB.get('checklists'),
    settings: DB.get('settings'),
    exportedAt: new Date().toISOString()
  };
  
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `spw-backup-${new Date().toISOString().split('T')[0]}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

function importData(input) {
  const file = input.files[0];
  if (!file) return;
  
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const data = JSON.parse(e.target.result);
      if (data.jobs) DB.set('jobs', data.jobs);
      if (data.clients) DB.set('clients', data.clients);
      if (data.team) DB.set('team', data.team);
      if (data.equipment) DB.set('equipment', data.equipment);
      if (data.checklists) DB.set('checklists', data.checklists);
      if (data.settings) DB.set('settings', data.settings);
      alert('Data imported successfully!');
      location.reload();
    } catch (err) {
      alert('Error importing data: ' + err.message);
    }
  };
  reader.readAsText(file);
}

function clearAllData() {
  if (!confirm('WARNING: This will delete ALL data. Are you sure?')) return;
  if (!confirm('Really sure? This cannot be undone.')) return;
  
  localStorage.removeItem('spw_initialized');
  localStorage.removeItem('spw_jobs');
  localStorage.removeItem('spw_clients');
  localStorage.removeItem('spw_team');
  localStorage.removeItem('spw_equipment');
  localStorage.removeItem('spw_checklists');
  localStorage.removeItem('spw_settings');
  localStorage.removeItem('spw_currentUser');
  
  alert('All data cleared. Reloading...');
  location.reload();
}

// ============================================================
// MODAL HELPERS
// ============================================================
function openModal(id) {
  document.getElementById(id).classList.add('open');
}

function closeModal(id) {
  document.getElementById(id).classList.remove('open');
}

function openQuickAction() {
  openModal('modalQuick');
}

// Close modals on escape
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal.open').forEach(m => m.classList.remove('open'));
  }
});

// ============================================================
// UTILITIES
// ============================================================
function getClient(id) {
  return (DB.get('clients') || []).find(c => c.id === id);
}

function getTeamMember(id) {
  return (DB.get('team') || []).find(t => t.id === id);
}

function formatDate(dateStr) {
  if (!dateStr) return 'N/A';
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-AU', { day: 'numeric', month: 'short', year: 'numeric' });
}

function serviceName(code) {
  const names = {
    'pressure-wash': 'Pressure Washing',
    'nano-ceramic': 'Nano Ceramic Shield',
    'anti-graffiti': 'Anti-Graffiti Armour',
    'anti-mould': 'Anti-Mould Defender',
    'inspection': 'Site Inspection'
  };
  return names[code] || code;
}

// Add detail styles for job view
const detailStyles = document.createElement('style');
detailStyles.textContent = `
  .job-detail-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}
  .detail-group label{display:block;color:var(--pearl-5);font-size:.85rem;font-weight:700;margin-bottom:6px;text-transform:uppercase;letter-spacing:.04em}
  .detail-group p{margin:0;color:var(--pearl-9);font-size:1rem;font-weight:600}
  .surface-tags{display:flex;flex-wrap:wrap;gap:8px}
  .surface-tag{padding:6px 14px;border-radius:999px;background:rgba(0,224,232,.1);border:1px solid rgba(0,224,232,.2);color:var(--aqua-7);font-weight:700;font-size:.85rem}
`;
document.head.appendChild(detailStyles);
