/* ============================================================
   SP NanoAssure™ — Employment & Workforce Data Layer
   Persistent localStorage + ready for Supabase migration
   Version: 2026.08.22.2
   ============================================================ */

const SP_EMP_STORE = {
  KEY: 'sp_employment_v1',
  defaults() {
    return {
      version: 1,
      vacancies: [],
      applications: [],
      candidates: [],
      employees: [],
      onboarding: [],
      licences: [],
      trainingAssignments: [],
      interviews: [],
      offers: [],
      tasks: [],
      audit: [],
      settings: {
        company: "Sam's Pro-Wash Solutions Pty Ltd",
        brand: 'SP NanoAssure™',
        location: 'Darwin, Northern Territory, Australia',
        abn: '95 698 841 128'
      }
    };
  },
  load() {
    try {
      const raw = localStorage.getItem(this.KEY);
      if (!raw) return this.defaults();
      const data = JSON.parse(raw);
      return Object.assign(this.defaults(), data);
    } catch (e) {
      console.warn('SP Emp load failed', e);
      return this.defaults();
    }
  },
  save(data) {
    localStorage.setItem(this.KEY, JSON.stringify(data));
  },
  mutate(fn) {
    const data = this.load();
    fn(data);
    this.save(data);
    return data;
  },
  audit(action, detail, actor) {
    this.mutate(d => {
      d.audit.unshift({
        id: 'AUD-' + Date.now(),
        at: new Date().toISOString(),
        action,
        detail: detail || '',
        actor: actor || (sessionStorage.getItem('sp_role') || 'system')
      });
      if (d.audit.length > 500) d.audit.length = 500;
    });
  }
};

const SP_EMP_IDS = {
  next(prefix) {
    return prefix + '-' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 5).toUpperCase();
  }
};

/* ---------- Seed demo data once ---------- */
function spEmpEnsureSeed() {
  const d = SP_EMP_STORE.load();
  if (d.vacancies.length || d.employees.length) return;
  const now = new Date();
  const iso = (days) => new Date(now.getTime() + days * 86400000).toISOString().slice(0, 10);

  d.vacancies = [
    {
      id: 'VAC-SEED1',
      title: 'NanoAssure Application Technician',
      department: 'Operations',
      type: 'Full-time',
      location: 'Darwin NT',
      status: 'Public',
      openings: 2,
      openDate: iso(-14),
      closeDate: iso(21),
      startDate: iso(35),
      description: 'Apply NanoAssure™ surface protection systems across commercial and government sites. Field-based role with GPS/QA logging.',
      duties: 'Surface prep, product application per TDS, QA photo evidence, site safety, daily reporting.',
      mandatory: ['White Card', 'Driver Licence', 'WHS induction'],
      desirable: ['Working at Heights', 'EWP', 'Previous coatings experience'],
      licences: ['White Card', 'C Class Driver'],
      createdAt: iso(-14)
    },
    {
      id: 'VAC-SEED2',
      title: 'Site Supervisor — Asset Protection',
      department: 'Operations',
      type: 'Full-time',
      location: 'Darwin NT',
      status: 'Internal',
      openings: 1,
      openDate: iso(-7),
      closeDate: iso(28),
      startDate: iso(45),
      description: 'Lead field crews on NanoAssure projects. Competency sign-off, deployment, WHS oversight.',
      duties: 'Crew leadership, site induction, QA gate checks, client liaison, timesheet approval.',
      mandatory: ['White Card', 'Supervisor experience', 'First Aid'],
      desirable: ['Construction supervision', 'NanoAssure product cert'],
      licences: ['White Card', 'First Aid'],
      createdAt: iso(-7)
    }
  ];

  d.applications = [
    {
      id: 'APP-SEED1',
      vacancyId: 'VAC-SEED1',
      name: 'Alex Rivera',
      email: 'alex.r@example.com',
      phone: '04xx xxx 001',
      suburb: 'Palmerston',
      state: 'NT',
      workRights: 'Australian Citizen',
      status: 'Interview',
      stage: 'Interview',
      availability: 'Immediate',
      experience: ['Commercial sites', 'Coatings', 'WHS'],
      licences: ['White Card', 'C Class'],
      createdAt: iso(-5),
      notes: []
    },
    {
      id: 'APP-SEED2',
      vacancyId: 'VAC-SEED1',
      name: 'Jordan Lee',
      email: 'jordan.l@example.com',
      phone: '04xx xxx 002',
      suburb: 'Casuarina',
      state: 'NT',
      workRights: 'Permanent Resident',
      status: 'Screening',
      stage: 'Screening',
      availability: '2 weeks notice',
      experience: ['Cleaning/preparation', 'Residential'],
      licences: ['White Card'],
      createdAt: iso(-2),
      notes: []
    }
  ];

  d.employees = [
    {
      id: 'EMP-001',
      empNo: 'SP-1001',
      name: 'Kate Operations',
      preferred: 'Kate',
      role: 'Operations Manager',
      type: 'Full-time',
      status: 'Active',
      supervisor: 'Director',
      startDate: '2025-03-01',
      email: 'kate@samsprowash.internal',
      phone: '04xx xxx 100',
      photo: '',
      competencies: ['NanoAssure Application', 'QA Gates', 'Chemical Mixing', 'Supervision'],
      colour: 'blue'
    },
    {
      id: 'EMP-002',
      empNo: 'SP-1002',
      name: 'Field Tech Demo',
      preferred: 'Tech',
      role: 'Application Technician',
      type: 'Casual',
      status: 'Active',
      supervisor: 'Kate Operations',
      startDate: '2025-11-15',
      email: 'tech@samsprowash.internal',
      phone: '04xx xxx 101',
      photo: '',
      competencies: ['NanoAssure Application', 'Pre-Cleaner Prep'],
      colour: 'blue'
    }
  ];

  d.licences = [
    { id: 'LIC-1', employeeId: 'EMP-001', type: 'White Card', number: 'WC-NT-DEMO', issuer: 'NT WorkSafe', issueDate: '2024-01-10', expiryDate: iso(120), status: 'VALID', verifiedBy: 'Director' },
    { id: 'LIC-2', employeeId: 'EMP-001', type: 'First Aid', number: 'FA-DEMO', issuer: 'St John', issueDate: '2025-06-01', expiryDate: iso(25), status: 'EXPIRING', verifiedBy: 'Director' },
    { id: 'LIC-3', employeeId: 'EMP-002', type: 'White Card', number: 'WC-NT-DEMO2', issuer: 'NT WorkSafe', issueDate: '2025-10-01', expiryDate: iso(200), status: 'VALID', verifiedBy: 'Kate' },
    { id: 'LIC-4', employeeId: 'EMP-002', type: 'Working at Heights', number: 'WAH-DEMO', issuer: 'RTO Demo', issueDate: '2025-08-01', expiryDate: iso(-5), status: 'EXPIRED', verifiedBy: 'Kate' }
  ];

  d.onboarding = [
    {
      id: 'ONB-1',
      applicationId: 'APP-SEED1',
      name: 'Alex Rivera',
      position: 'NanoAssure Application Technician',
      startDate: iso(35),
      supervisor: 'Kate Operations',
      steps: [
        { key: 'agreement', label: 'Employment Agreement', done: true },
        { key: 'personal', label: 'Personal Details', done: true },
        { key: 'emergency', label: 'Emergency Contact', done: false },
        { key: 'banking', label: 'Banking Details', done: false },
        { key: 'super', label: 'Superannuation', done: false },
        { key: 'tfn', label: 'TFN Declaration', done: false },
        { key: 'workrights', label: 'Work Rights Verification', done: true },
        { key: 'licence', label: 'Driver Licence Verification', done: false },
        { key: 'certs', label: 'Certificates Verified', done: false },
        { key: 'ppe', label: 'PPE Requirements', done: false },
        { key: 'whs', label: 'WHS Induction', done: false },
        { key: 'policies', label: 'Company Policies', done: false },
        { key: 'nanotrain', label: 'NanoAssure™ Training', done: false },
        { key: 'equipment', label: 'Equipment Authorisation', done: false },
        { key: 'vehicle', label: 'Vehicle Authorisation', done: false },
        { key: 'supervisor', label: 'Supervisor Induction', done: false },
        { key: 'final', label: 'Final Approval', done: false }
      ]
    }
  ];

  d.interviews = [
    {
      id: 'INT-1',
      applicationId: 'APP-SEED1',
      candidate: 'Alex Rivera',
      vacancy: 'NanoAssure Application Technician',
      interviewer: 'Kate Operations',
      date: iso(3),
      time: '10:00',
      duration: 45,
      mode: 'In-person',
      status: 'Scheduled',
      location: 'Darwin Operations Base'
    }
  ];

  SP_EMP_STORE.save(d);
  SP_EMP_STORE.audit('SEED', 'Demo employment data loaded');
}

/* ---------- Helpers ---------- */
function spEmpDaysUntil(dateStr) {
  if (!dateStr) return null;
  const t = new Date(dateStr + 'T00:00:00').getTime();
  const n = new Date();
  n.setHours(0, 0, 0, 0);
  return Math.round((t - n.getTime()) / 86400000);
}

function spEmpLicenceStatus(expiryDate) {
  const days = spEmpDaysUntil(expiryDate);
  if (days === null) return 'PENDING';
  if (days < 0) return 'EXPIRED';
  if (days <= 30) return 'EXPIRING';
  return 'VALID';
}

function spEmpRefreshLicenceStatuses() {
  SP_EMP_STORE.mutate(d => {
    d.licences.forEach(l => {
      l.status = spEmpLicenceStatus(l.expiryDate);
    });
  });
}

function spEmpPipelineStages() {
  return ['Applied', 'Review', 'Screening', 'Shortlist', 'Interview', 'Reference Check', 'Offer', 'Hired'];
}

function spEmpKpis() {
  const d = SP_EMP_STORE.load();
  spEmpRefreshLicenceStatuses();
  const data = SP_EMP_STORE.load();
  const vacOpen = data.vacancies.filter(v => ['Public', 'Internal', 'Paused'].includes(v.status));
  const apps = data.applications;
  const hired = apps.filter(a => a.stage === 'Hired' || a.status === 'Hired');
  const onb = data.onboarding;
  const emp = data.employees.filter(e => e.status === 'Active');
  const expiring = data.licences.filter(l => l.status === 'EXPIRING' || l.status === 'EXPIRED');
  return {
    vacancies: { total: vacOpen.length, public: vacOpen.filter(v => v.status === 'Public').length },
    applications: { total: apps.length, week: apps.filter(a => spEmpDaysUntil(a.createdAt) >= -7).length },
    candidates: { active: apps.filter(a => !['Hired', 'Unsuccessful', 'Withdrawn'].includes(a.stage)).length, interviews: data.interviews.filter(i => i.status === 'Scheduled').length },
    hired: { recent: hired.length },
    onboarding: { active: onb.length, overdue: onb.filter(o => o.steps.some(s => !s.done)).length },
    workforce: { active: emp.length, contractors: emp.filter(e => e.type === 'Contractor' || e.type === 'Casual').length },
    expiry: { alerts: expiring.length, expired: data.licences.filter(l => l.status === 'EXPIRED').length }
  };
}

// Auto-seed on load
if (typeof window !== 'undefined') {
  try { spEmpEnsureSeed(); } catch (e) { console.warn(e); }
}

window.SP_EMP_STORE = SP_EMP_STORE;
window.SP_EMP_IDS = SP_EMP_IDS;
window.spEmpEnsureSeed = spEmpEnsureSeed;
window.spEmpKpis = spEmpKpis;
window.spEmpDaysUntil = spEmpDaysUntil;
window.spEmpLicenceStatus = spEmpLicenceStatus;
window.spEmpRefreshLicenceStatuses = spEmpRefreshLicenceStatuses;
window.spEmpPipelineStages = spEmpPipelineStages;
