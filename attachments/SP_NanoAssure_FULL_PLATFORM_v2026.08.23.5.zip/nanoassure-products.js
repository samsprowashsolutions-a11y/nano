/* ============================================================
   Sam's Pro-Wash Solutions / NanoAssure™ — Product Catalog
   Source of truth: Nanoman / Nanotech Products official TDS & SDS
   Cross-checked: 22 Aug 2026 against live PDFs on nanoman.com.au
   Gaps fixed: Stone+Brick added · Non-Porous AG pinned to TDS-42a ·
               Pre-Cleaner coverage · RH notes aligned
   ============================================================ */

const SP_NANOASSURE_PRODUCTS = [
  {
    id: 'ag-porous',
    name: 'Nanoman Anti-Graffiti (Porous)',
    tds: 'TDS-41a v0.7 (April 2025)',
    sds: 'SDS Nanoman Anti Graffiti (Porous) — FILE NTP/AGP/1006 · dated 01/02/24',
    sdsUrl: 'https://nanoman.com.au/wp-content/uploads/2024/02/SDS-41a_Nanoman_Anti-Graffiti_Porous-Surfaces.pdf',
    dataSheetsHub: 'https://nanoman.com.au/data-sheets/',
    substrate: 'Porous — concrete, masonry, brickwork, terracotta, wood/timber (incl. painted), furniture',
    coats: 'Single coat only (one coat)',
    coverage: '80–100 ml/m² average with recommended spray; higher if brush/roller; varies with substrate absorbance',
    env: 'Ambient 5–35°C · RH ≤ 90% (TDS also notes preferred 30–80%) · surface absolutely dry · remain dry through cure window',
    dryTimes: 'Touch dry ~1 h · completely dry 4–5 h · fully cured 7 days',
    substrateTests: [
      'Substrate type = porous (not metal/plastic — use Non-Porous AG for those)',
      'Clean, absolutely dry; free of laitance, form oil, curing membrane, grease, dirt',
      'New concrete minimum 14 days cure; Schmidt Hammer 2500–3000 psi may allow earlier',
      'Fully cured concrete by day 28 preferred',
      'Painted/mural surfaces fully dry (min 24 h); test adhesion on inconspicuous area'
    ],
    envTests: [
      'Air / ambient temperature 5–35°C',
      'Relative humidity 90% or less (preferred 30–80% per TDS)',
      'Do not apply to wet/damp surfaces or if rain will wet the film during the dry window',
      'Surface remains dry for the completely-dry period (4–5 h)'
    ],
    apas: {
      applicable: true,
      code: 'APAS 1441',
      title: 'Permanent Graffiti Barrier',
      note: 'CSIRO testing to APAS 1441 — Results: Complies. Report: Testing of Anti-Graffiti Coating to APAS 1441, August 2021. Includes protection against graffiti (Appendix A), surface dry, reincorporation after storage, resistance to natural weathering. Permanent (non-sacrificial) barrier. This is manufacturer laboratory testing — not a site re-test.',
      short: 'APAS 1441 · CSIRO tested Complies (Aug 2021 report)'
    },
    certNote: 'Applied per Nanoman TDS-41a v0.7 (April 2025). Single coat. Product tested by CSIRO to APAS 1441 (Complies, Aug 2021). Nanoassure™ gates confirm substrate class, prep, environment and coat count.',
    sourceUrl: 'https://nanoman.com.au/wp-content/uploads/2025/04/TDS-41a_Anti-Graffiti-v0.7-April-25.pdf'
  },
  {
    id: 'ag-nonporous',
    name: 'Nanoman Anti-Graffiti (Non-Porous)',
    tds: 'TDS-42a Anti-Graffiti NP v0.3 (Feb 2024)',
    sds: 'SDS Nanoman Anti Graffiti Non Porous — FILE NTP/AGNP/1004 · dated 01/02/24',
    sdsUrl: 'https://nanoman.com.au/wp-content/uploads/2024/02/SDS_42a_Nanoman_Anti-Graffiti_NonPorous_Rev1.pdf',
    dataSheetsHub: 'https://nanoman.com.au/data-sheets/',
    substrate: 'Smooth non-absorbent — metals (aluminium, zinc, stainless, copper, brass, bronze, corten, galvanised), powder-coated, polyurethane/epoxy/polyester paints, GRP, plastics',
    coats: 'Single coat only — do not use porous AG product on these substrates',
    coverage: '10–12 ml/m² (do not over-apply; light film only)',
    env: 'Substrate +5 to +30°C · ambient ≥ +5°C · RH 30–80% · surface absolutely dry · no rain/wind-driven dust',
    dryTimes: 'Touch dry ~1 h · completely dry 4–5 h · fully cured 5–7 days at room temperature (faster with heat assist per TDS)',
    substrateTests: [
      'Substrate = non-porous metal / painted / GRP / plastic (not porous masonry or timber)',
      'Clean, grease-free, ABSOLUTELY DRY — no oil, silicone, wax, fluorination',
      'Contaminants removed with suitable cleaner/solvent; cavities blown dry if needed',
      'Rusted metal: remove loose rust/scale before coating'
    ],
    envTests: [
      'Substrate temperature +5 to +30°C',
      'Relative humidity 30–80%',
      'Do not apply to damp surfaces or in rain',
      'Dust-free conditions preferred; avoid high wind'
    ],
    apas: { applicable: false, code: '', title: '', note: '', short: '' },
    certNote: 'Applied per Nanoman TDS-42a v0.3. Single coat 10–12 ml/m². Effective life approx. 7–10 years when applied correctly. Nanoassure™ gates confirm substrate class, absolute dryness, RH window and light-film coverage.',
    sourceUrl: 'https://nanoman.com.au/wp-content/uploads/2024/02/TDS-42a_Anti-Graffiti_NP-v0.3.pdf'
  },
  {
    id: 'glass-ceramic',
    name: 'Nanoman Glass + Ceramic',
    tds: 'TDS-03a GlassCeramic v0.2 (Feb 2024)',
    sds: 'SDS Glass + Ceramic — confirm current PDF on Data Sheets hub',
    sdsUrl: 'https://nanoman.com.au/data-sheets/',
    dataSheetsHub: 'https://nanoman.com.au/data-sheets/',
    substrate: 'Glass, ceramic, porcelain, mirrors, shower screens, tiles (incl. grout), basins, baths, toilets, splashbacks — non-porous only',
    coats: 'Single thin film (ready to use)',
    coverage: '8–10 ml/m² typical (range 5–15 ml/m²); 100 ml treats ~10 m²',
    env: '5–35°C · RH ≤ 90% · surface clean & dry · prefer shade / dust-free',
    dryTimes: 'Initial dry 2–5 min · allow up to 1 h (longer if humid) · optimal performance after 24 h',
    substrateTests: [
      'Non-porous glass / ceramic / porcelain only',
      'Prepared with Nanoman Pre Cleaner — clean, dry, free of residues',
      'No film-tint glass without confirming compatibility'
    ],
    envTests: [
      'Temperature 5–35°C (not below 7.22°C or above 35°C per alternate TDS note)',
      'RH 90% or less',
      'Dust-free application preferred'
    ],
    apas: { applicable: false, code: '', title: '', note: '', short: '' },
    certNote: 'Applied per Nanoman TDS-03a v0.2. Single thin film 8–10 ml/m². ISO 11507 referenced on manufacturer TDS. Pre-Cleaner prep required. Nanoassure™ gates confirm prep, coverage and environment.',
    sourceUrl: 'https://nanoman.com.au/wp-content/uploads/2024/02/TDS-03a_GlassCeramic-v0.2.pdf'
  },
  {
    id: 'stone-brick',
    name: 'Nanoman Stone + Brick',
    tds: 'TDS-10a Stone+Brick v0.5 (Revised January 2025)',
    sds: 'SDS Stone + Brick — confirm current PDF on Data Sheets hub',
    sdsUrl: 'https://nanoman.com.au/data-sheets/',
    dataSheetsHub: 'https://nanoman.com.au/data-sheets/',
    substrate: 'Porous mineral — natural stone (marble, granite, limestone, sandstone, travertine), brick, concrete, cementitious materials. NOT for low-porosity resin engineered stone (Caesarstone, Silestone, Quantum Quartz etc.)',
    coats: 'One coat application',
    coverage: '50–80 ml/m² depending on absorbency',
    env: '7.22–35°C · no rain 12–24 h · prefer shade · keep surface dry 24 h after application',
    dryTimes: 'Surface dry 2–3 h typical · avoid traffic/rain min 6 h · water resistant almost immediately · optimal performance ~5 days',
    substrateTests: [
      'Porous mineral only — not resin-based engineered stone',
      'Completely clean, dry; free of dirt, dust, grease, old coatings, oil, algae, mould, mill glaze',
      'Test small inconspicuous area first',
      'On polished surfaces: do not allow pooling; wipe excess after ~15 min'
    ],
    envTests: [
      'Air/surface temperature not below 7.22°C or above 35°C',
      'No rain expected within 12–24 hours',
      'Applied out of direct sun where practicable',
      'Keep dry for 24 hours after application'
    ],
    apas: { applicable: false, code: '', title: '', note: '', short: '' },
    certNote: 'Applied per Nanoman TDS-10a v0.5 (Jan 2025). One coat 50–80 ml/m². ISO 11507 certified. Nanoassure™ gates confirm porous mineral substrate, prep, temperature window and coat count.',
    sourceUrl: 'https://nanoman.com.au/wp-content/uploads/2025/02/TDS-10a_StoneMBrick-v0.5.pdf'
  },
  {
    id: 'pre-cleaner',
    name: 'Nanoman Pre Cleaner',
    tds: 'TDS-00a Pre-Cleaner v0.1',
    sds: 'SDS Pre Cleaner — confirm current PDF on Data Sheets hub',
    sdsUrl: 'https://nanoman.com.au/data-sheets/',
    dataSheetsHub: 'https://nanoman.com.au/data-sheets/',
    substrate: 'Non-porous only — glass, windows, ceramic tiles, shower screens, stainless steel, metal, solar panels. Do NOT use on porous surfaces or film-tinted glass.',
    coats: 'N/A — preparation product, not a finish coating',
    coverage: '60–80 ml/m² typical (depends on soiling); liberally spray small sections (~40×40 cm)',
    env: 'Well ventilated · prefer shade · keep away from ignition sources (contains isopropanol)',
    dryTimes: 'Quick evaporating — surface typically dry ~30 min; must be completely dry before nano coating',
    substrateTests: [
      'Non-porous substrate only',
      'Not used on porous surfaces or film-tinted glass',
      'Surface free of heavy built-up stains (chemical clean first if needed, then Pre Cleaner)'
    ],
    envTests: [
      'Well ventilated area',
      'No open flame / hot surfaces during use'
    ],
    apas: { applicable: false, code: '', title: '', note: '', short: '' },
    certNote: 'Used per Nanoman TDS-00a as surface preparation only. Coverage ~60–80 ml/m². Not a protective coating. Nanoassure™ gates confirm non-porous substrate and full dry-down before finish coat.',
    sourceUrl: 'https://nanoman.com.au/wp-content/uploads/2024/02/TDS-00a_Pre-Cleaner-v0.1.pdf'
  },
  {
    id: 'antimicrobial',
    name: 'Nanoman Antimicrobial Hard Surfaces',
    tds: 'TDS-07a Antimicrobial Hard Surfaces (Rev Feb 2024)',
    sds: 'SDS Antimicrobial — confirm current PDF on Data Sheets hub',
    sdsUrl: 'https://nanoman.com.au/data-sheets/',
    dataSheetsHub: 'https://nanoman.com.au/data-sheets/',
    substrate: 'Hard surfaces — metal, plastic, glass, polished timber, stone',
    coats: 'Spray and wipe; do not thin',
    coverage: '15 ml/m² average',
    env: '5–35°C typical application window',
    dryTimes: 'Allow to dry ~10 minutes',
    substrateTests: [
      'Hard surface suitable for antimicrobial coating',
      'Clean surface prior to application'
    ],
    envTests: [
      'Temperature within 5–35°C'
    ],
    apas: { applicable: false, code: '', title: '', note: '', short: '' },
    certNote: 'Applied per Nanoman TDS-07a. Coverage 15 ml/m². Dry ~10 min. TGA ARTG registration referenced by manufacturer for antimicrobial claims. Nanoassure™ gates confirm coverage and dry time.',
    sourceUrl: 'https://nanoman.com.au/wp-content/uploads/2024/02/TDS-07a_Antimicrobial-Hard-Surfaces-3-002.pdf'
  },
  {
    id: 'raw-timber',
    name: 'Nanoman Raw Timber',
    tds: 'TDS-11a Raw Timber v0.3 (Feb 2024)',
    sds: 'SDS Raw Timber — confirm current PDF on Data Sheets hub',
    sdsUrl: 'https://nanoman.com.au/data-sheets/',
    dataSheetsHub: 'https://nanoman.com.au/data-sheets/',
    substrate: 'Raw timber only (not painted or varnished)',
    coats: 'One coat application',
    coverage: '50–80 ml/m² depending on absorbency (~250 ml covers ~3 m²)',
    env: '7.22–35°C · no rain 12–24 h · prefer shade · store product +5 to +25°C',
    dryTimes: 'Surface dry 2–3 h typical · allow 12–24 h before use/wetting · optimal performance ~5 days',
    substrateTests: [
      'Raw timber only (not painted/varnished)',
      'Dry, clean; free of mill glaze, mould, oil, old coatings',
      'Weathered timber sanded/cleaned; absorbency checked with water sprinkle test'
    ],
    envTests: [
      'Temperature not below 7.22°C or above 35°C',
      'No rain expected within 12–24 hours',
      'Applied out of direct sun where practicable'
    ],
    apas: { applicable: false, code: '', title: '', note: '', short: '' },
    certNote: 'Applied per Nanoman TDS-11a v0.3. One coat, 50–80 ml/m². ISO 11507 referenced on manufacturer TDS. Nanoassure™ gates confirm prep, temperature and coat count.',
    sourceUrl: 'https://nanoman.com.au/wp-content/uploads/2024/02/TDS-11a_Raw-Timber-v0.3.pdf'
  },
  {
    id: 'wheels',
    name: 'Nanoman Wheels',
    tds: 'TDS-32a Wheels v0.1',
    sds: 'SDS Wheels (SiO₂ / ethanol — flash point 11°C) — confirm current PDF on Data Sheets',
    sdsUrl: 'https://nanoman.com.au/data-sheets/',
    dataSheetsHub: 'https://nanoman.com.au/data-sheets/',
    substrate: 'Alloy and metal wheels/rims (car, trailer, truck, motorbike); does not affect rubber',
    coats: 'Per TDS — spray then wipe; buff after dry',
    coverage: '8–12 ml per wheel (approx. 8–12 ml/m²); 100 ml treats at least 8 wheels',
    env: '5–35°C · RH ≤ 90% · avoid wet conditions, rain, direct sun, hot wheels',
    dryTimes: 'Dry ~60 minutes (longer if humid), then buff with microfibre',
    substrateTests: [
      'Wheel/rim substrate',
      'Prepared with Nanoman Pre Cleaner — clean, dry, free of grease and brake dust'
    ],
    envTests: [
      'Temperature 5–35°C · RH 90% or less',
      'Not applied on wet, raining, or hot wheels'
    ],
    apas: { applicable: false, code: '', title: '', note: '', short: '' },
    certNote: 'Applied per Nanoman TDS-32a. Coverage 8–12 ml/wheel. Pre-Cleaner prep required. Life 2+ years in ideal conditions. Nanoassure™ gates confirm prep, environment and coverage.',
    sourceUrl: 'https://nanoman.com.au/wp-content/uploads/2024/02/TDS-32a_Wheels-v0.1.pdf'
  }

];

function spGetNanoProduct(idOrName) {
  const q = (idOrName || '').toString().toLowerCase();
  return SP_NANOASSURE_PRODUCTS.find(p =>
    p.id === q || p.name.toLowerCase() === q || p.name.toLowerCase().includes(q)
  ) || null;
}

function spApasNoteForProduct(idOrName) {
  const p = spGetNanoProduct(idOrName);
  if (!p || !p.apas || !p.apas.applicable) return '';
  return p.apas.note;
}

function spCertNoteForProduct(idOrName) {
  const p = spGetNanoProduct(idOrName);
  return p ? p.certNote : '';
}

function spApplyProductToQA(productId, opts) {
  opts = opts || {};
  const p = spGetNanoProduct(productId);
  if (!p) return null;
  const set = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.value = val;
  };
  if (opts.productField !== false) set(opts.productField || 'qaProduct', p.name);
  if (opts.tdsField !== false) set(opts.tdsField || 'qaTDS', p.tds);
  const apasEl = document.getElementById(opts.apasField || 'qaApasNote');
  if (apasEl) {
    if (apasEl.tagName === 'TEXTAREA' || apasEl.tagName === 'INPUT') {
      apasEl.value = p.apas && p.apas.applicable ? p.apas.short : 'Not applicable to this product';
    } else {
      apasEl.textContent = p.apas && p.apas.applicable ? p.apas.note : 'APAS 1441 does not apply to this product path.';
    }
  }
  const testsEl = document.getElementById(opts.testsField || 'qaProductTests');
  if (testsEl) {
    const lines = []
      .concat(['Substrate tests:'], p.substrateTests.map(t => '• ' + t))
      .concat(['Environmental tests:'], p.envTests.map(t => '• ' + t))
      .concat([
        'Coats: ' + p.coats,
        'Coverage: ' + p.coverage,
        'Environment: ' + p.env,
        'Dry / cure: ' + (p.dryTimes || '—'),
        'TDS: ' + (p.sourceUrl || 'Nanoman TDS'),
        'SDS: ' + (p.sdsUrl || p.dataSheetsHub || 'https://nanoman.com.au/data-sheets/')
      ]);
    testsEl.textContent = lines.join('\n');
  }
  return p;
}

function spFillProductSelect(selectId) {
  const sel = document.getElementById(selectId || 'qaProductSelect');
  if (!sel) return;
  sel.innerHTML = '<option value="">— Select Nanoman product —</option>' +
    SP_NANOASSURE_PRODUCTS.map(p =>
      '<option value="' + p.id + '">' + p.name + (p.apas && p.apas.applicable ? ' · APAS 1441' : '') + '</option>'
    ).join('');
}

function spApasCertificateHtml(productName) {
  const p = spGetNanoProduct(productName);
  if (!p) {
    return '<div class="sp-apas-note" style="margin-top:12px;padding:12px;border-radius:10px;border:1px solid rgba(200,206,214,.3);background:rgba(28,18,48,.5);font-size:.82rem;line-height:1.45;color:#c8c8d8;">'
      + '<b style="color:#F0D68C;">Manufacturer reference</b><br>'
      + 'Product claims and application conditions per the current Nanoman TDS/SDS only. Verify the latest PDF on nanoman.com.au before certification.'
      + '</div>';
  }
  let html = '<div class="sp-apas-note" style="margin-top:12px;padding:12px;border-radius:10px;border:1px solid rgba(217,180,74,.35);background:linear-gradient(165deg,rgba(217,180,74,.08),rgba(28,18,48,.55));font-size:.82rem;line-height:1.5;color:#e8e0f0;">'
    + '<div style="font-size:.68rem;letter-spacing:.08em;text-transform:uppercase;color:#9AA0A8;margin-bottom:6px;">Nanoassure™ · Manufacturer standards (TDS primary source)</div>'
    + '<b style="color:#F0D68C;">' + p.name + '</b><br>'
    + '<span style="color:#3EE0D6;">TDS:</span> ' + p.tds + '<br>'
    + '<span style="color:#3EE0D6;">SDS:</span> ' + p.sds
    + (p.sdsUrl ? ' · <a href="'+p.sdsUrl+'" target="_blank" rel="noopener" style="color:#3EE0D6;">Open SDS</a>' : '')
    + '<br>'
    + (p.sourceUrl ? '<span style="color:#3EE0D6;">TDS PDF:</span> <a href="'+p.sourceUrl+'" target="_blank" rel="noopener" style="color:#3EE0D6;">Open TDS</a><br>' : '')
    + '<span style="color:#3EE0D6;">Coats / coverage:</span> ' + p.coats + ' · ' + p.coverage + '<br>'
    + '<span style="color:#3EE0D6;">Dry / cure:</span> ' + (p.dryTimes || '—') + '<br>';
  if (p.apas && p.apas.applicable) {
    html += '<div style="margin-top:8px;padding:8px 10px;border-left:3px solid #C9A227;background:rgba(0,0,0,.25);border-radius:0 8px 8px 0;">'
      + '<b style="color:#F0D68C;">' + p.apas.code + ' — ' + p.apas.title + '</b><br>'
      + p.apas.note
      + '</div>';
  }
  html += '<div style="margin-top:8px;color:#9AA0A8;">' + p.certNote + '</div></div>';
  return html;
}

window.SP_NANOASSURE_PRODUCTS = SP_NANOASSURE_PRODUCTS;
window.spGetNanoProduct = spGetNanoProduct;
window.spApasNoteForProduct = spApasNoteForProduct;
window.spCertNoteForProduct = spCertNoteForProduct;
window.spApplyProductToQA = spApplyProductToQA;
window.spFillProductSelect = spFillProductSelect;
window.spApasCertificateHtml = spApasCertificateHtml;
