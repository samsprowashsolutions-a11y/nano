// Netlify serverless function: server-side proxy for B.O.M. Darwin Airport (station 94120) observations.
// Deploy this file to netlify/functions/bom-darwin.js in the site repo (already supported by your existing
// Netlify site). This avoids the browser CORS block that direct client-side fetches to bom.gov.au will hit.
//
// Usage from the app: fetch('/.netlify/functions/bom-darwin')
//
// Data source: Bureau of Meteorology, Australia (ABN 92 637 533 532).
// For personal/organisational use only per BOM's data feed terms — not for resale or redistribution.
// See: https://www.bom.gov.au/catalogue/data-feeds.shtml

const BOM_URL = 'http://www.bom.gov.au/fwo/IDD60801/IDD60801.94120.json';

exports.handler = async function () {
  try {
    const res = await fetch(BOM_URL, {
      headers: { 'User-Agent': 'SamsProwashSolutions-OpsApp/1.0' }
    });
    if (!res.ok) {
      return {
        statusCode: 502,
        headers: { 'Access-Control-Allow-Origin': '*' },
        body: JSON.stringify({ error: 'B.O.M. responded with HTTP ' + res.status })
      };
    }
    const data = await res.json();
    return {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Cache-Control': 'public, max-age=300' // BOM refreshes ~every 30 min; 5 min cache is safe
      },
      body: JSON.stringify(data)
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers: { 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ error: err.message })
    };
  }
};
