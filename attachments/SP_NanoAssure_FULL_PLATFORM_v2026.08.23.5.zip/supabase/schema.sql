-- ============================================================
-- Sam's Prowash Solutions (SP) — Supabase Schema + RLS
-- Nanoassure™ Quality Assurance & Digital Verification
-- Region recommendation: ap-southeast-2 (Sydney)
-- Run this in the Supabase SQL Editor (as project owner)
-- ============================================================

-- Extensions
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ------------------------------------------------------------
-- 1. PROFILES (extends auth.users)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT,
  display_name TEXT NOT NULL DEFAULT '',
  role TEXT NOT NULL CHECK (role IN ('director','cultural','operations','staff','client')),
  employee_no TEXT,
  active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, display_name, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_app_meta_data->>'role', 'staff')
  );
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Helper: current user's role
CREATE OR REPLACE FUNCTION public.current_role()
RETURNS TEXT
LANGUAGE sql
STABLE
SECURITY DEFINER SET search_path = public
AS $$
  SELECT role FROM public.profiles WHERE id = auth.uid();
$$;

CREATE OR REPLACE FUNCTION public.is_director()
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'director' AND active);
$$;

CREATE OR REPLACE FUNCTION public.is_ops_or_director()
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role IN ('operations','director') AND active);
$$;

CREATE OR REPLACE FUNCTION public.is_cultural_or_director()
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role IN ('cultural','director') AND active);
$$;

CREATE OR REPLACE FUNCTION public.is_staff_or_above()
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role IN ('staff','operations','cultural','director') AND active);
$$;

-- ------------------------------------------------------------
-- 2. PROJECTS (22-step workflow)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  client_name TEXT,
  step INT NOT NULL DEFAULT 0 CHECK (step >= 0 AND step <= 21),
  crew TEXT,
  status TEXT DEFAULT 'active',
  created_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ------------------------------------------------------------
-- 3. SUBSTRATE TESTS (Nanoassure™)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.substrate_tests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_name TEXT NOT NULL,
  test_area TEXT,
  substrate TEXT,
  ph NUMERIC,
  moisture NUMERIC,
  age_days NUMERIC,
  air_temp TEXT,
  surface_temp TEXT,
  instrument TEXT,
  prep TEXT,
  notes TEXT,
  gps TEXT,
  photo_path TEXT,          -- Storage path in field-photos bucket
  tested_by TEXT,
  auto_result TEXT,         -- PASS / FAIL reason
  approved_at TIMESTAMPTZ,
  approved_by TEXT,
  created_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ------------------------------------------------------------
-- 4. ENVIRONMENTAL CHECKS (Nanoassure™)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.environmental_checks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_name TEXT NOT NULL,
  air_temp NUMERIC,
  rh NUMERIC,
  surface_temp NUMERIC,
  dew_gap NUMERIC,
  wind TEXT,
  sky TEXT,
  direct_sun BOOLEAN DEFAULT false,
  rain_24h BOOLEAN DEFAULT false,
  instrument TEXT,
  notes TEXT,
  gps TEXT,
  photo_path TEXT,
  verdict TEXT,             -- COMPLIANT / WARRANTY VOID …
  approved_at TIMESTAMPTZ,
  approved_by TEXT,
  created_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ------------------------------------------------------------
-- 5. QA SIGNOFFS / Nanoassure Digital Verification
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.qa_signoffs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  verification_id TEXT NOT NULL UNIQUE,  -- NA-YYYYMMDD-XXXX
  job_name TEXT NOT NULL,
  product TEXT NOT NULL,
  applicator TEXT NOT NULL,
  substrate_ref TEXT,
  env_ref TEXT,
  tds_ref TEXT,
  batch_lot TEXT,
  gate_result TEXT NOT NULL DEFAULT '8/8',
  status TEXT NOT NULL DEFAULT 'VERIFIED',
  certified_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_qa_verification_id ON public.qa_signoffs (verification_id);

-- ------------------------------------------------------------
-- 6. STAFF / TIMESHEETS / INCIDENTS
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.staff (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_no TEXT UNIQUE,
  name TEXT NOT NULL,
  role_title TEXT,
  start_date DATE,
  annual_leave_hrs NUMERIC DEFAULT 0,
  white_card TEXT,
  first_aid TEXT,
  cultural_training TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.timesheets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  staff_name TEXT NOT NULL,
  event TEXT NOT NULL CHECK (event IN ('ON','OFF','BREAK','RESUME')),
  event_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by UUID REFERENCES public.profiles(id)
);

CREATE TABLE IF NOT EXISTS public.staff_incidents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  staff_name TEXT NOT NULL,
  incident_date DATE,
  severity TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ------------------------------------------------------------
-- 7. CHEMICAL MIXES
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.chemical_mixes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_name TEXT,
  product TEXT,
  volume_ml NUMERIC,
  mixed_by TEXT,
  mixed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ,   -- 24h shelf life
  notes TEXT,
  created_by UUID REFERENCES public.profiles(id)
);

-- ------------------------------------------------------------
-- 8. CULTURAL MODULE
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.cultural_engagements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  engagement_date DATE NOT NULL,
  who TEXT,
  activity TEXT,
  created_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.cultural_screenings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  screening_date DATE NOT NULL DEFAULT CURRENT_DATE,
  job_name TEXT NOT NULL,
  community TEXT,
  decision TEXT NOT NULL CHECK (decision IN ('APPROVED','HOLD','DECLINED')),
  notes TEXT,
  created_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.cultural_incidents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  who TEXT,
  incident_date DATE,
  notes TEXT,
  resolved_date DATE,
  created_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.cultural_certs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  person_name TEXT NOT NULL,
  cert_name TEXT NOT NULL,
  expiry_date DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ------------------------------------------------------------
-- 9. RECEIPTS / EXPENSES
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.receipts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  vendor TEXT NOT NULL,
  amount NUMERIC NOT NULL CHECK (amount > 0),
  expense_date DATE,
  category TEXT,
  job_tag TEXT,
  gst TEXT,
  notes TEXT,
  logged_by TEXT,
  created_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ------------------------------------------------------------
-- 10. TRAINING CERTIFICATES
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.certifications (
  id TEXT PRIMARY KEY,          -- certificate ID from academy
  person_name TEXT NOT NULL,
  topic TEXT NOT NULL,
  score NUMERIC,
  issued_date DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ------------------------------------------------------------
-- 11. AUDIT TRAIL (append-only)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.audit_events (
  id TEXT PRIMARY KEY,          -- AUD-…
  ts TIMESTAMPTZ NOT NULL DEFAULT now(),
  action TEXT NOT NULL,
  module TEXT,
  role_at_time TEXT,
  details JSONB DEFAULT '{}'::jsonb,
  created_by UUID REFERENCES public.profiles(id)
);

CREATE INDEX IF NOT EXISTS idx_audit_ts ON public.audit_events (ts DESC);
CREATE INDEX IF NOT EXISTS idx_audit_action ON public.audit_events (action);

-- ------------------------------------------------------------
-- 12. CLIENT ACCESS CODES
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.client_access (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_name TEXT NOT NULL,
  access_code TEXT NOT NULL,
  expires_at DATE,
  created_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================================
-- ROW LEVEL SECURITY — ENABLE ON ALL TABLES
-- ============================================================
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.substrate_tests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.environmental_checks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.qa_signoffs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.staff ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.timesheets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.staff_incidents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chemical_mixes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cultural_engagements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cultural_screenings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cultural_incidents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cultural_certs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.receipts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.certifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.client_access ENABLE ROW LEVEL SECURITY;

-- ============================================================
-- RLS POLICIES
-- ============================================================

-- ---------- PROFILES ----------
CREATE POLICY "profiles_select_own_or_director"
  ON public.profiles FOR SELECT TO authenticated
  USING ( id = auth.uid() OR public.is_director() );

CREATE POLICY "profiles_update_own_or_director"
  ON public.profiles FOR UPDATE TO authenticated
  USING ( id = auth.uid() OR public.is_director() )
  WITH CHECK ( id = auth.uid() OR public.is_director() );

-- ---------- PROJECTS ----------
CREATE POLICY "projects_select_staff"
  ON public.projects FOR SELECT TO authenticated
  USING ( public.is_staff_or_above() );

CREATE POLICY "projects_insert_ops"
  ON public.projects FOR INSERT TO authenticated
  WITH CHECK ( public.is_ops_or_director() );

CREATE POLICY "projects_update_ops"
  ON public.projects FOR UPDATE TO authenticated
  USING ( public.is_ops_or_director() )
  WITH CHECK ( public.is_ops_or_director() );

CREATE POLICY "projects_delete_director"
  ON public.projects FOR DELETE TO authenticated
  USING ( public.is_director() );

-- ---------- SUBSTRATE TESTS ----------
CREATE POLICY "tests_select_staff"
  ON public.substrate_tests FOR SELECT TO authenticated
  USING ( public.is_staff_or_above() );

CREATE POLICY "tests_insert_ops"
  ON public.substrate_tests FOR INSERT TO authenticated
  WITH CHECK ( public.is_ops_or_director() );

CREATE POLICY "tests_update_ops"   -- approvals
  ON public.substrate_tests FOR UPDATE TO authenticated
  USING ( public.is_ops_or_director() OR public.is_cultural_or_director() )
  WITH CHECK ( public.is_ops_or_director() OR public.is_cultural_or_director() );

CREATE POLICY "tests_delete_director"
  ON public.substrate_tests FOR DELETE TO authenticated
  USING ( public.is_director() );

-- ---------- ENVIRONMENTAL CHECKS ----------
CREATE POLICY "env_select_staff"
  ON public.environmental_checks FOR SELECT TO authenticated
  USING ( public.is_staff_or_above() );

CREATE POLICY "env_insert_ops"
  ON public.environmental_checks FOR INSERT TO authenticated
  WITH CHECK ( public.is_ops_or_director() );

CREATE POLICY "env_update_ops"
  ON public.environmental_checks FOR UPDATE TO authenticated
  USING ( public.is_ops_or_director() OR public.is_cultural_or_director() )
  WITH CHECK ( public.is_ops_or_director() OR public.is_cultural_or_director() );

CREATE POLICY "env_delete_director"
  ON public.environmental_checks FOR DELETE TO authenticated
  USING ( public.is_director() );

-- ---------- QA SIGNOFFS (Nanoassure Digital Verification) ----------
-- Authenticated staff can read; public verify uses a SECURITY DEFINER function (below)
CREATE POLICY "qa_select_staff"
  ON public.qa_signoffs FOR SELECT TO authenticated
  USING ( public.is_staff_or_above() );

CREATE POLICY "qa_insert_ops"
  ON public.qa_signoffs FOR INSERT TO authenticated
  WITH CHECK ( public.is_ops_or_director() );

CREATE POLICY "qa_update_director"
  ON public.qa_signoffs FOR UPDATE TO authenticated
  USING ( public.is_director() )
  WITH CHECK ( public.is_director() );

CREATE POLICY "qa_delete_director"
  ON public.qa_signoffs FOR DELETE TO authenticated
  USING ( public.is_director() );

-- Public read-only lookup by verification_id (no auth required)
CREATE OR REPLACE FUNCTION public.verify_nanoassure(p_id TEXT)
RETURNS TABLE (
  verification_id TEXT,
  job_name TEXT,
  product TEXT,
  applicator TEXT,
  certified_at TIMESTAMPTZ,
  status TEXT
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT verification_id, job_name, product, applicator, certified_at, status
  FROM public.qa_signoffs
  WHERE upper(verification_id) = upper(p_id)
  LIMIT 1;
$$;

GRANT EXECUTE ON FUNCTION public.verify_nanoassure(TEXT) TO anon, authenticated;

-- ---------- STAFF ----------
CREATE POLICY "staff_select_staff"
  ON public.staff FOR SELECT TO authenticated
  USING ( public.is_staff_or_above() );

CREATE POLICY "staff_write_ops"
  ON public.staff FOR ALL TO authenticated
  USING ( public.is_ops_or_director() )
  WITH CHECK ( public.is_ops_or_director() );

-- ---------- TIMESHEETS ----------
CREATE POLICY "timesheets_select_staff"
  ON public.timesheets FOR SELECT TO authenticated
  USING ( public.is_staff_or_above() );

CREATE POLICY "timesheets_insert_ops"
  ON public.timesheets FOR INSERT TO authenticated
  WITH CHECK ( public.is_ops_or_director() OR public.is_staff_or_above() );

CREATE POLICY "timesheets_delete_director"
  ON public.timesheets FOR DELETE TO authenticated
  USING ( public.is_director() );

-- ---------- STAFF INCIDENTS ----------
CREATE POLICY "staff_inc_select_ops"
  ON public.staff_incidents FOR SELECT TO authenticated
  USING ( public.is_ops_or_director() OR public.is_cultural_or_director() );

CREATE POLICY "staff_inc_write_ops"
  ON public.staff_incidents FOR ALL TO authenticated
  USING ( public.is_ops_or_director() )
  WITH CHECK ( public.is_ops_or_director() );

-- ---------- CHEMICAL MIXES ----------
CREATE POLICY "chem_select_staff"
  ON public.chemical_mixes FOR SELECT TO authenticated
  USING ( public.is_staff_or_above() );

CREATE POLICY "chem_write_ops"
  ON public.chemical_mixes FOR ALL TO authenticated
  USING ( public.is_ops_or_director() )
  WITH CHECK ( public.is_ops_or_director() );

-- ---------- CULTURAL ----------
CREATE POLICY "cult_eng_select"
  ON public.cultural_engagements FOR SELECT TO authenticated
  USING ( public.is_cultural_or_director() OR public.is_ops_or_director() );

CREATE POLICY "cult_eng_write"
  ON public.cultural_engagements FOR ALL TO authenticated
  USING ( public.is_cultural_or_director() )
  WITH CHECK ( public.is_cultural_or_director() );

CREATE POLICY "cult_screen_select"
  ON public.cultural_screenings FOR SELECT TO authenticated
  USING ( public.is_cultural_or_director() OR public.is_ops_or_director() );

CREATE POLICY "cult_screen_write"
  ON public.cultural_screenings FOR ALL TO authenticated
  USING ( public.is_cultural_or_director() )
  WITH CHECK ( public.is_cultural_or_director() );

CREATE POLICY "cult_inc_select"
  ON public.cultural_incidents FOR SELECT TO authenticated
  USING ( public.is_cultural_or_director() OR public.is_ops_or_director() );

CREATE POLICY "cult_inc_write"
  ON public.cultural_incidents FOR ALL TO authenticated
  USING ( public.is_cultural_or_director() )
  WITH CHECK ( public.is_cultural_or_director() );

CREATE POLICY "cult_certs_select"
  ON public.cultural_certs FOR SELECT TO authenticated
  USING ( public.is_cultural_or_director() OR public.is_ops_or_director() );

CREATE POLICY "cult_certs_write"
  ON public.cultural_certs FOR ALL TO authenticated
  USING ( public.is_cultural_or_director() )
  WITH CHECK ( public.is_cultural_or_director() );

-- ---------- RECEIPTS ----------
CREATE POLICY "receipts_select_finance"
  ON public.receipts FOR SELECT TO authenticated
  USING ( public.is_director() OR public.is_cultural_or_director() OR public.is_ops_or_director() );

CREATE POLICY "receipts_insert_staff"
  ON public.receipts FOR INSERT TO authenticated
  WITH CHECK ( public.is_staff_or_above() );

CREATE POLICY "receipts_delete_director"
  ON public.receipts FOR DELETE TO authenticated
  USING ( public.is_director() );

-- ---------- CERTIFICATIONS (academy) ----------
CREATE POLICY "certs_select_staff"
  ON public.certifications FOR SELECT TO authenticated
  USING ( public.is_staff_or_above() );

CREATE POLICY "certs_write_cultural"
  ON public.certifications FOR ALL TO authenticated
  USING ( public.is_cultural_or_director() )
  WITH CHECK ( public.is_cultural_or_director() );

-- ---------- AUDIT EVENTS (append-only for normal roles) ----------
CREATE POLICY "audit_select_director_ops_cultural"
  ON public.audit_events FOR SELECT TO authenticated
  USING ( public.is_director() OR public.is_ops_or_director() OR public.is_cultural_or_director() );

CREATE POLICY "audit_insert_authenticated"
  ON public.audit_events FOR INSERT TO authenticated
  WITH CHECK ( public.is_staff_or_above() );

-- No UPDATE or DELETE policies for non-directors → append-only
CREATE POLICY "audit_delete_director_only"
  ON public.audit_events FOR DELETE TO authenticated
  USING ( public.is_director() );

-- ---------- CLIENT ACCESS ----------
CREATE POLICY "client_access_select_staff"
  ON public.client_access FOR SELECT TO authenticated
  USING ( public.is_staff_or_above() );

CREATE POLICY "client_access_write_director"
  ON public.client_access FOR ALL TO authenticated
  USING ( public.is_director() OR public.is_ops_or_director() )
  WITH CHECK ( public.is_director() OR public.is_ops_or_director() );

-- ============================================================
-- STORAGE BUCKET (run after creating bucket 'field-photos' in dashboard)
-- Policies on storage.objects
-- ============================================================
-- Create bucket via Dashboard: Storage → New bucket → name: field-photos → Private

-- Example policies (uncomment after bucket exists):
/*
CREATE POLICY "field_photos_select_staff"
  ON storage.objects FOR SELECT TO authenticated
  USING ( bucket_id = 'field-photos' AND public.is_staff_or_above() );

CREATE POLICY "field_photos_insert_ops"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK ( bucket_id = 'field-photos' AND public.is_ops_or_director() );

CREATE POLICY "field_photos_update_ops"
  ON storage.objects FOR UPDATE TO authenticated
  USING ( bucket_id = 'field-photos' AND public.is_ops_or_director() );

CREATE POLICY "field_photos_delete_director"
  ON storage.objects FOR DELETE TO authenticated
  USING ( bucket_id = 'field-photos' AND public.is_director() );
*/

-- ============================================================
-- GRANTS
-- ============================================================
GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO authenticated;
GRANT INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO authenticated;
GRANT EXECUTE ON FUNCTION public.current_role() TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_director() TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_ops_or_director() TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_cultural_or_director() TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_staff_or_above() TO authenticated;
GRANT EXECUTE ON FUNCTION public.verify_nanoassure(TEXT) TO anon, authenticated;

-- ============================================================
-- DONE
-- After running:
-- 1. Create Storage bucket "field-photos" (private)
-- 2. Uncomment storage policies above and re-run that block
-- 3. Create first Director user in Auth, then:
--    UPDATE public.profiles SET role = 'director' WHERE email = 'your@email.com';
-- 4. Add supabaseClient.js to the platform and begin parallel writes
-- ============================================================
