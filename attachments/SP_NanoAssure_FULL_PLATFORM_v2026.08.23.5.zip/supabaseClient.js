/* ============================================================
   Sam's Prowash Solutions — Supabase Client Scaffold
   Nanoassure™ Quality Assurance & Digital Verification
   ------------------------------------------------------------
   SETUP:
   1. Create project at https://supabase.com (region: Sydney / ap-southeast-2)
   2. Run supabase/schema.sql in the SQL Editor
   3. Create Storage bucket "field-photos" (private)
   4. Paste your Project URL and anon (public) key below
   5. Load this file on pages that need the backend:
        <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
        <script src="supabaseClient.js"></script>
   ------------------------------------------------------------
   NEVER put the service_role key in browser code.
   ============================================================ */

const SP_SUPABASE_URL = 'https://YOUR_PROJECT_REF.supabase.co';   // CHANGE ME
const SP_SUPABASE_ANON_KEY = 'YOUR_ANON_PUBLIC_KEY';              // CHANGE ME

let spSupabase = null;

function spInitSupabase() {
  if (spSupabase) return spSupabase;
  if (typeof supabase === 'undefined' || !supabase.createClient) {
    console.warn('Supabase JS SDK not loaded. Parallel writes disabled.');
    return null;
  }
  if (SP_SUPABASE_URL.includes('YOUR_PROJECT') || SP_SUPABASE_ANON_KEY.includes('YOUR_ANON')) {
    console.info('Supabase credentials not configured yet — running localStorage only.');
    return null;
  }
  spSupabase = supabase.createClient(SP_SUPABASE_URL, SP_SUPABASE_ANON_KEY, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true
    }
  });
  return spSupabase;
}

/* ---------- Auth helpers ---------- */
async function spSignIn(email, password) {
  const client = spInitSupabase();
  if (!client) return { error: 'Supabase not configured' };
  return client.auth.signInWithPassword({ email, password });
}

async function spSignOut() {
  const client = spInitSupabase();
  if (!client) return;
  return client.auth.signOut();
}

async function spGetSession() {
  const client = spInitSupabase();
  if (!client) return null;
  const { data } = await client.auth.getSession();
  return data.session;
}

async function spGetMyProfile() {
  const client = spInitSupabase();
  if (!client) return null;
  const { data: { user } } = await client.auth.getUser();
  if (!user) return null;
  const { data, error } = await client.from('profiles').select('*').eq('id', user.id).single();
  if (error) { console.warn(error); return null; }
  return data;
}

/* ---------- Parallel write: Nanoassure Digital Verification ---------- */
async function spWriteQaSignoff(payload) {
  // payload: { verificationId, job, product, applicator, subRef, envRef, tds, batch }
  const client = spInitSupabase();
  if (!client) return { skipped: true };

  const row = {
    verification_id: payload.verificationId,
    job_name: payload.job,
    product: payload.product,
    applicator: payload.applicator,
    substrate_ref: payload.subRef || null,
    env_ref: payload.envRef || null,
    tds_ref: payload.tds || null,
    batch_lot: payload.batch || null,
    gate_result: '8/8',
    status: 'VERIFIED',
    certified_at: new Date().toISOString()
  };

  const { data, error } = await client.from('qa_signoffs').insert(row).select().single();
  if (error) {
    console.warn('Supabase qa_signoffs insert failed (localStorage still has the record):', error.message);
    return { error };
  }
  return { data };
}

/* ---------- Parallel write: Audit event ---------- */
async function spWriteAuditEvent(entry) {
  // entry shape matches spAudit() output
  const client = spInitSupabase();
  if (!client) return { skipped: true };

  const row = {
    id: entry.id,
    ts: entry.tsIso || new Date().toISOString(),
    action: entry.action,
    module: entry.module || null,
    role_at_time: entry.role || null,
    details: entry.details || {}
  };

  const { error } = await client.from('audit_events').insert(row);
  if (error) {
    console.warn('Supabase audit_events insert failed:', error.message);
    return { error };
  }
  return { ok: true };
}

/* ---------- Public verify (uses SECURITY DEFINER function) ---------- */
async function spVerifyNanoassure(verificationId) {
  const client = spInitSupabase();
  if (!client) {
    // Fallback to localStorage (current behaviour)
    try {
      const list = JSON.parse(localStorage.getItem('sp_nanoassure_verifications') || '[]');
      const found = list.find(v => (v.id || '').toUpperCase() === (verificationId || '').toUpperCase());
      return found ? {
        verification_id: found.id,
        job_name: found.job,
        product: found.product,
        applicator: found.applicator,
        certified_at: found.stamp,
        status: found.status || 'VERIFIED'
      } : null;
    } catch (e) { return null; }
  }

  const { data, error } = await client.rpc('verify_nanoassure', { p_id: verificationId });
  if (error) {
    console.warn(error);
    return null;
  }
  return (data && data[0]) ? data[0] : null;
}

/* ---------- Optional: substrate test parallel write ---------- */
async function spWriteSubstrateTest(test) {
  const client = spInitSupabase();
  if (!client) return { skipped: true };

  const row = {
    job_name: test.j || test.job,
    test_area: test.area || null,
    substrate: test.s || test.substrate || null,
    ph: test.ph,
    moisture: test.mo || test.moisture,
    age_days: test.age === '—' ? null : test.age,
    air_temp: test.air || null,
    surface_temp: test.surfT || null,
    instrument: test.inst || null,
    prep: test.prep || null,
    notes: test.notes || null,
    gps: test.gps || null,
    photo_path: test.photoPath || null,  // after Storage upload
    tested_by: test.by || null,
    auto_result: test.auto || null
  };

  const { data, error } = await client.from('substrate_tests').insert(row).select().single();
  if (error) {
    console.warn('Supabase substrate_tests insert failed:', error.message);
    return { error };
  }
  return { data };
}

/* ---------- Hook existing spAudit so it also writes to Supabase ---------- */
(function patchAudit() {
  if (typeof spAudit !== 'function') return;
  const original = spAudit;
  window.spAudit = function (action, details, module) {
    const id = original(action, details, module);
    // Fire-and-forget parallel write
    try {
      const log = JSON.parse(localStorage.getItem('sp_audit_trail') || '[]');
      const entry = log.find(e => e.id === id) || { id, action, details, module, tsIso: new Date().toISOString() };
      spWriteAuditEvent(entry);
    } catch (e) {}
    return id;
  };
})();

// Initialise on load (safe no-op until keys are set)
if (typeof document !== 'undefined') {
  document.addEventListener('DOMContentLoaded', () => spInitSupabase());
}
